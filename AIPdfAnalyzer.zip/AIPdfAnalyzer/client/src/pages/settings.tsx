import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { fetchCurrentUser, fetchIntegrations, updateUserSettings, toggleIntegration, getDateRanges } from '@/lib/api';
import { DateRange, User, Integration } from '@/types';
import Sidebar from '@/components/dashboard/Sidebar';
import Header from '@/components/dashboard/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ShoppingBag, CreditCard, Settings2, User as UserIcon } from 'lucide-react';
import { RiGoogleLine } from 'react-icons/ri';
import { FaLinkedin, FaInstagram } from 'react-icons/fa';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';

const SettingsPage: React.FC = () => {
  const dateRanges = getDateRanges();
  const [selectedDateRange, setSelectedDateRange] = useState<DateRange>(dateRanges[2]);
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    tavusApiKey: '',
    openaiApiKey: '',
    stripeSecretKey: '',
    stripePublicKey: '',
    apifyApiKey: ''
  });

  // Fetch user data
  const { 
    data: userData,
    isLoading: isUserLoading
  } = useQuery({ 
    queryKey: ['/api/users/me'],
    queryFn: () => fetchCurrentUser(),
    onSuccess: (data) => {
      if (data) {
        setFormData(prev => ({
          ...prev,
          username: data.username || '',
          email: data.email || '',
          tavusApiKey: data.tavusApiKey || '',
          openaiApiKey: data.openaiApiKey || '',
          stripeSecretKey: data.stripeSecretKey || '',
          stripePublicKey: data.stripePublicKey || '',
          apifyApiKey: data.apifyApiKey || ''
        }));
      }
    }
  });

  // Fetch integrations data
  const { 
    data: integrationsData,
    isLoading: isIntegrationsLoading
  } = useQuery({ 
    queryKey: ['/api/integrations'],
    queryFn: () => fetchIntegrations()
  });

  // Update user settings mutation
  const updateUserMutation = useMutation({
    mutationFn: (data: Partial<User>) => updateUserSettings(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/me'] });
      toast({
        title: "Settings updated",
        description: "Your profile settings have been updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error updating settings",
        description: error.message || "An error occurred while updating your settings",
        variant: "destructive",
      });
    }
  });

  // Toggle integration mutation
  const toggleIntegrationMutation = useMutation({
    mutationFn: ({ id, isConnected }: { id: string, isConnected: boolean }) => 
      toggleIntegration(id, isConnected),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/integrations'] });
      toast({
        title: "Integration updated",
        description: "Your integration settings have been updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error updating integration",
        description: error.message || "An error occurred while updating the integration",
        variant: "destructive",
      });
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserMutation.mutate({
      username: formData.username,
      email: formData.email,
      // Include other fields as needed
    });
  };

  const handleToggleIntegration = (id: string, isConnected: boolean) => {
    toggleIntegrationMutation.mutate({ id, isConnected: !isConnected });
  };

  const handleDateRangeChange = (dateRange: DateRange) => {
    setSelectedDateRange(dateRange);
  };

  const handleRefreshData = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/users/me'] });
    queryClient.invalidateQueries({ queryKey: ['/api/integrations'] });
  };

  const getIntegrationIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'shopify':
        return <ShoppingBag className="h-6 w-6" />;
      case 'stripe':
        return <CreditCard className="h-6 w-6" />;
      case 'google_analytics':
        return <RiGoogleLine className="h-6 w-6" />;
      case 'linkedin':
        return <FaLinkedin className="h-6 w-6" />;
      case 'instagram':
        return <FaInstagram className="h-6 w-6" />;
      default:
        return <Settings2 className="h-6 w-6" />;
    }
  };

  if (isUserLoading || isIntegrationsLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin h-12 w-12 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar 
        integrations={integrationsData || []}
        user={userData || {
          id: '1',
          username: 'User',
          initials: 'U',
          role: 'Founder',
          email: 'user@example.com'
        }}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          selectedDateRange={selectedDateRange}
          dateRanges={dateRanges}
          onDateRangeChange={handleDateRangeChange}
          onRefreshData={handleRefreshData}
        />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-neutral-50 dark:bg-neutral-900">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">Settings</h1>
              <p className="text-neutral-500 dark:text-neutral-400">
                Manage your account settings and connected integrations
              </p>
            </div>
            
            <Tabs defaultValue="profile">
              <TabsList className="mb-8">
                <TabsTrigger value="profile">Profile</TabsTrigger>
                <TabsTrigger value="integrations">Integrations</TabsTrigger>
                <TabsTrigger value="api-keys">API Keys</TabsTrigger>
              </TabsList>
              
              <TabsContent value="profile">
                <Card>
                  <CardHeader>
                    <CardTitle>Profile Settings</CardTitle>
                    <CardDescription>
                      Update your profile information
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSaveSettings}>
                      <div className="grid gap-6">
                        <div className="grid gap-3">
                          <Label htmlFor="username">Username</Label>
                          <Input
                            id="username"
                            name="username"
                            value={formData.username}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="grid gap-3">
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleInputChange}
                          />
                        </div>
                      </div>
                    </form>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      onClick={handleSaveSettings}
                      disabled={updateUserMutation.isPending}
                    >
                      {updateUserMutation.isPending ? 'Saving...' : 'Save Changes'}
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              
              <TabsContent value="integrations">
                <div className="grid gap-6">
                  {integrationsData?.map((integration: Integration) => (
                    <Card key={integration.id}>
                      <CardHeader>
                        <div className="flex items-center space-x-4">
                          <div className="p-2 rounded-md bg-neutral-100 dark:bg-neutral-800">
                            {getIntegrationIcon(integration.type)}
                          </div>
                          <div>
                            <CardTitle>{integration.name}</CardTitle>
                            <CardDescription>
                              {integration.isConnected ? 'Connected' : 'Disconnected'}
                            </CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-neutral-500 dark:text-neutral-400">
                          {integration.type === 'shopify' 
                            ? 'Connect your Shopify store to track sales, products, and customer metrics.'
                            : integration.type === 'stripe'
                            ? 'Connect your Stripe account to track revenue, subscriptions, and payment stats.'
                            : integration.type === 'google_analytics'
                            ? 'Connect Google Analytics to track website traffic, user behavior, and acquisition channels.'
                            : integration.type === 'linkedin'
                            ? 'Connect LinkedIn to track engagement, followers, and content performance.'
                            : 'Connect to track key performance metrics and analytics.'
                          }
                        </p>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <div className="flex items-center space-x-2">
                          <Switch 
                            checked={integration.isConnected} 
                            onCheckedChange={() => handleToggleIntegration(integration.id, integration.isConnected)}
                            disabled={toggleIntegrationMutation.isPending}
                          />
                          <Label>{integration.isConnected ? 'Enabled' : 'Disabled'}</Label>
                        </div>
                        <Button variant="outline" size="sm">Configure</Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="api-keys">
                <Card>
                  <CardHeader>
                    <CardTitle>API Keys</CardTitle>
                    <CardDescription>
                      Manage your API keys for external services
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-6">
                      <div className="grid gap-3">
                        <Label htmlFor="tavusApiKey">Tavus API Key</Label>
                        <Input
                          id="tavusApiKey"
                          name="tavusApiKey"
                          type="password"
                          value={formData.tavusApiKey}
                          onChange={handleInputChange}
                          placeholder="sk_tavus_******"
                        />
                      </div>
                      <div className="grid gap-3">
                        <Label htmlFor="openaiApiKey">OpenAI API Key</Label>
                        <Input
                          id="openaiApiKey"
                          name="openaiApiKey"
                          type="password"
                          value={formData.openaiApiKey}
                          onChange={handleInputChange}
                          placeholder="sk-******"
                        />
                      </div>
                      <div className="grid gap-3">
                        <Label htmlFor="stripeSecretKey">Stripe Secret Key</Label>
                        <Input
                          id="stripeSecretKey"
                          name="stripeSecretKey"
                          type="password"
                          value={formData.stripeSecretKey}
                          onChange={handleInputChange}
                          placeholder="sk_live_******"
                        />
                      </div>
                      <div className="grid gap-3">
                        <Label htmlFor="stripePublicKey">Stripe Public Key</Label>
                        <Input
                          id="stripePublicKey"
                          name="stripePublicKey"
                          value={formData.stripePublicKey}
                          onChange={handleInputChange}
                          placeholder="pk_live_******"
                        />
                      </div>
                      <div className="grid gap-3">
                        <Label htmlFor="apifyApiKey">Apify API Key</Label>
                        <Input
                          id="apifyApiKey"
                          name="apifyApiKey"
                          type="password"
                          value={formData.apifyApiKey}
                          onChange={handleInputChange}
                          placeholder="apify_api_******"
                        />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      onClick={handleSaveSettings}
                      disabled={updateUserMutation.isPending}
                    >
                      {updateUserMutation.isPending ? 'Saving...' : 'Save API Keys'}
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
};

export default SettingsPage;