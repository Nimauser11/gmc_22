import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { fetchTavusReports, createTavusReport, getDateRanges } from '@/lib/api';
import { TavusReport, DateRange } from '@/types';
import Sidebar from '@/components/dashboard/Sidebar';
import Header from '@/components/dashboard/Header';
import TavusIntegration from '@/components/dashboard/TavusIntegration';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { VideoIcon, Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';

const TavusReports: React.FC = () => {
  const dateRanges = getDateRanges();
  const [selectedDateRange, setSelectedDateRange] = useState<DateRange>(dateRanges[2]); // Default to 'Last 7 days'
  const [showNewReportDialog, setShowNewReportDialog] = useState(false);
  const [newReportTitle, setNewReportTitle] = useState('');
  const [newReportType, setNewReportType] = useState<'investor' | 'team' | 'customer' | 'custom'>('investor');
  const { toast } = useToast();

  const { 
    data: reports, 
    isLoading,
    refetch 
  } = useQuery({ 
    queryKey: ['/api/tavus/reports'],
    queryFn: () => fetchTavusReports()
  });

  const createReportMutation = useMutation({
    mutationFn: (data: {title: string, reportType: string}) => 
      createTavusReport(data as any),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tavus/reports'] });
      toast({
        title: "Report created",
        description: "Your personalized video report is being generated",
      });
      setShowNewReportDialog(false);
      setNewReportTitle('');
    },
    onError: (error: any) => {
      toast({
        title: "Error creating report",
        description: error.message || "An error occurred while creating the report",
        variant: "destructive",
      });
    }
  });

  const handleDateRangeChange = (dateRange: DateRange) => {
    setSelectedDateRange(dateRange);
  };

  const handleRefreshData = () => {
    refetch();
  };

  const handleCreateReport = () => {
    if (!newReportTitle.trim()) {
      toast({
        title: "Title required",
        description: "Please enter a title for your report",
        variant: "destructive",
      });
      return;
    }

    createReportMutation.mutate({
      title: newReportTitle,
      reportType: newReportType
    });
  };

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin h-12 w-12 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!reports) {
    return <div>Error loading Tavus reports</div>;
  }

  // Get dashboard data from the previous location
  const dashboardData = JSON.parse(localStorage.getItem('dashboardData') || '{}');
  const { user, integrations } = dashboardData;

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar 
        integrations={integrations || []}
        user={user || {
          id: '1',
          username: 'User',
          initials: 'U',
          role: 'Founder',
          email: 'user@example.com'
        }}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          selectedDateRange={selectedDateRange}
          dateRanges={dateRanges}
          onDateRangeChange={handleDateRangeChange}
          onRefreshData={handleRefreshData}
        />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-neutral-50 dark:bg-neutral-900">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h1 className="text-3xl font-bold mb-2">Tavus AI Video Reports</h1>
                <p className="text-neutral-500 dark:text-neutral-400">
                  Create and manage personalized AI-generated video reports
                </p>
              </div>
              
              <Button 
                onClick={() => setShowNewReportDialog(true)}
                className="flex items-center gap-2"
              >
                <Plus className="h-4 w-4" />
                <span>New Report</span>
              </Button>
            </div>
            
            {reports.length === 0 ? (
              <div className="bg-white dark:bg-neutral-800 rounded-lg shadow p-8 text-center">
                <VideoIcon className="h-12 w-12 mx-auto mb-4 text-neutral-400" />
                <h3 className="text-lg font-medium mb-2">No reports yet</h3>
                <p className="text-neutral-500 dark:text-neutral-400 mb-6">
                  Create your first Tavus AI video report to share insights with your team or investors
                </p>
                <Button 
                  onClick={() => setShowNewReportDialog(true)}
                  className="mx-auto"
                >
                  Create First Report
                </Button>
              </div>
            ) : (
              <TavusIntegration tavusReports={reports} />
            )}
          </div>
        </main>
      </div>
      
      <Dialog open={showNewReportDialog} onOpenChange={setShowNewReportDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Video Report</DialogTitle>
            <DialogDescription>
              Use Tavus AI to generate a personalized video report for your stakeholders
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="title">Report Title</Label>
              <Input 
                id="title" 
                placeholder="Q1 Performance Report" 
                value={newReportTitle}
                onChange={(e) => setNewReportTitle(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label>Report Type</Label>
              <RadioGroup 
                value={newReportType} 
                onValueChange={(value) => setNewReportType(value as any)}
                className="flex flex-col space-y-1"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="investor" id="investor" />
                  <Label htmlFor="investor">Investor Update</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="team" id="team" />
                  <Label htmlFor="team">Team Update</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="customer" id="customer" />
                  <Label htmlFor="customer">Customer Update</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="custom" id="custom" />
                  <Label htmlFor="custom">Custom Report</Label>
                </div>
              </RadioGroup>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowNewReportDialog(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCreateReport}
              disabled={createReportMutation.isPending}
            >
              {createReportMutation.isPending ? 
                <div className="flex items-center gap-2">
                  <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full"></div>
                  <span>Creating...</span>
                </div> : 
                'Create Report'
              }
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TavusReports;