import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchDashboardData, getDateRanges } from '@/lib/api';
import { DashboardState, DateRange } from '@/types';
import Sidebar from '@/components/dashboard/Sidebar';
import Header from '@/components/dashboard/Header';
import MetricsCard from '@/components/dashboard/MetricsCard';
import AnomalyAlerts from '@/components/dashboard/AnomalyAlerts';
import FunnelAnalysis from '@/components/dashboard/FunnelAnalysis';
import TavusIntegration from '@/components/dashboard/TavusIntegration';
import CompetitorAnalysis from '@/components/dashboard/CompetitorAnalysis';
import AskKPIx from '@/components/dashboard/AskKPIx';

const Dashboard: React.FC = () => {
  const dateRanges = getDateRanges();
  const [selectedDateRange, setSelectedDateRange] = useState<DateRange>(dateRanges[2]); // Default to 'Last 7 days'

  const { 
    data, 
    isLoading,
    refetch 
  } = useQuery<DashboardState>({ 
    queryKey: ['/api/dashboard', selectedDateRange.value],
    queryFn: () => fetchDashboardData(selectedDateRange.value)
  });

  const handleDateRangeChange = (dateRange: DateRange) => {
    setSelectedDateRange(dateRange);
  };

  const handleRefreshData = () => {
    refetch();
  };

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin h-12 w-12 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!data) {
    return <div>Error loading dashboard data</div>;
  }
  
  // Store dashboard data in localStorage for other pages to access
  localStorage.setItem('dashboardData', JSON.stringify({
    user: data.user,
    integrations: data.integrations
  }));

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar 
        integrations={data.integrations}
        user={data.user}
      />

      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          selectedDateRange={selectedDateRange}
          dateRanges={dateRanges}
          onDateRangeChange={handleDateRangeChange}
          onRefreshData={handleRefreshData}
        />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-neutral-50">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-xl font-semibold">Overview</h2>
              <p className="text-neutral-600">Track your key performance metrics</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {data.metrics.map((metric) => (
              <MetricsCard key={metric.id} metric={metric} />
            ))}
          </div>
          
          <AnomalyAlerts anomalies={data.anomalies} />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <FunnelAnalysis funnelStages={data.funnelStages} />
            <TavusIntegration tavusReports={data.tavusReports} />
          </div>
          
          <CompetitorAnalysis competitors={data.competitors} />
          
          <AskKPIx previousQueries={data.aiQueries} />
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
