import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchMetrics, getDateRanges } from '@/lib/api';
import { useState } from 'react';
import { DateRange } from '@/types';
import Sidebar from '@/components/dashboard/Sidebar';
import Header from '@/components/dashboard/Header';

const Analytics: React.FC = () => {
  const dateRanges = getDateRanges();
  const [selectedDateRange, setSelectedDateRange] = useState<DateRange>(dateRanges[2]); // Default to 'Last 7 days'

  const { 
    data: metrics, 
    isLoading,
    refetch 
  } = useQuery({ 
    queryKey: ['/api/metrics', selectedDateRange.value],
    queryFn: () => fetchMetrics(selectedDateRange.value)
  });

  const handleDateRangeChange = (dateRange: DateRange) => {
    setSelectedDateRange(dateRange);
  };

  const handleRefreshData = () => {
    refetch();
  };

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin h-12 w-12 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!metrics) {
    return <div>Error loading analytics data</div>;
  }

  // Get dashboard data from the previous location
  const dashboardData = JSON.parse(localStorage.getItem('dashboardData') || '{}');
  const { user, integrations } = dashboardData;

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar 
        integrations={integrations || []}
        user={user || {
          id: '1',
          username: 'User',
          initials: 'U',
          role: 'Founder',
          email: 'user@example.com'
        }}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          selectedDateRange={selectedDateRange}
          dateRanges={dateRanges}
          onDateRangeChange={handleDateRangeChange}
          onRefreshData={handleRefreshData}
        />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-neutral-50 dark:bg-neutral-900">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">Advanced Analytics</h1>
              <p className="text-neutral-500 dark:text-neutral-400">
                Detailed metrics and insights for your business performance
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {metrics.map((metric) => (
                <div 
                  key={metric.id} 
                  className="bg-white dark:bg-neutral-800 rounded-lg shadow p-6"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-medium">{metric.title}</h3>
                      <p className="text-neutral-500 dark:text-neutral-400 text-sm">
                        Source: {metric.source}
                      </p>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <div className="text-3xl font-bold">{metric.value}</div>
                    <div className="flex items-center mt-1">
                      <span className={`text-sm ${metric.trend === 'up' ? 'text-success-500' : 'text-error-500'}`}>
                        {metric.trend === 'up' ? '↑' : '↓'} {metric.changePercentage}%
                      </span>
                      <span className="text-neutral-500 dark:text-neutral-400 text-sm ml-2">
                        vs previous period
                      </span>
                    </div>
                  </div>
                  
                  <div>
                    <div className="h-12 flex items-end space-x-1">
                      {metric.chartData.map((value, i) => (
                        <div 
                          key={i}
                          className="bg-primary bg-opacity-20 hover:bg-opacity-30 transition-all rounded-t"
                          style={{ 
                            height: `${Math.max(value * 100, 10)}%`,
                            width: `${100 / metric.chartData.length - 1}%` 
                          }}
                        ></div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Analytics;