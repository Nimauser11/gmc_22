import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchCompetitors, getDateRanges } from '@/lib/api';
import { useState } from 'react';
import { DateRange } from '@/types';
import Sidebar from '@/components/dashboard/Sidebar';
import Header from '@/components/dashboard/Header';
import CompetitorAnalysis from '@/components/dashboard/CompetitorAnalysis';

const Competitors: React.FC = () => {
  const dateRanges = getDateRanges();
  const [selectedDateRange, setSelectedDateRange] = useState<DateRange>(dateRanges[2]); // Default to 'Last 7 days'

  const { 
    data: competitors, 
    isLoading,
    refetch 
  } = useQuery({ 
    queryKey: ['/api/competitors'],
    queryFn: () => fetchCompetitors()
  });

  const handleDateRangeChange = (dateRange: DateRange) => {
    setSelectedDateRange(dateRange);
  };

  const handleRefreshData = () => {
    refetch();
  };

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin h-12 w-12 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!competitors) {
    return <div>Error loading competitors data</div>;
  }

  // Get dashboard data from the previous location
  const dashboardData = JSON.parse(localStorage.getItem('dashboardData') || '{}');
  const { user, integrations } = dashboardData;

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar 
        integrations={integrations || []}
        user={user || {
          id: '1',
          username: 'User',
          initials: 'U',
          role: 'Founder',
          email: 'user@example.com'
        }}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          selectedDateRange={selectedDateRange}
          dateRanges={dateRanges}
          onDateRangeChange={handleDateRangeChange}
          onRefreshData={handleRefreshData}
        />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-neutral-50 dark:bg-neutral-900">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">Competitor Analysis</h1>
              <p className="text-neutral-500 dark:text-neutral-400">
                Track and analyze your top competitors' performance and strategies
              </p>
            </div>
            
            <div className="grid grid-cols-1 gap-6">
              <CompetitorAnalysis competitors={competitors} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Competitors;