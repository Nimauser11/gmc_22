export type MetricCard = {
  id: string;
  title: string;
  value: string | number;
  previousValue: string | number;
  changePercentage: number;
  trend: 'up' | 'down';
  chartData: number[];
  source: string;
};

export type AnomalyAlert = {
  id: string;
  title: string;
  description: string;
  time: string;
  severity: 'warning' | 'success' | 'error';
  status: 'pending' | 'investigating' | 'resolved' | 'dismissed';
  icon: string;
};

export type FunnelStage = {
  id: string;
  name: string;
  value: number;
  percentage: number;
  dropPercentage: number;
};

export type TavusReport = {
  id: string;
  title: string;
  createdAt: string;
  thumbnailUrl: string;
  videoUrl: string;
  reportType: 'investor' | 'team' | 'customer' | 'custom';
};

export type Competitor = {
  id: string;
  name: string;
  initial: string;
  traffic: string;
  growth: number;
  channels: string[];
  strategy: string;
};

export type AiQuery = {
  id: string;
  query: string;
  response: string;
  timestamp: string;
};

export type Integration = {
  id: string;
  type: string;
  isConnected: boolean;
  icon: string;
  name: string;
};

export type User = {
  id: string;
  username: string;
  initials: string;
  role: string;
  email: string;
};

export type DateRange = {
  label: string;
  value: string;
  startDate: Date;
  endDate: Date;
};

export type DashboardState = {
  metrics: MetricCard[];
  anomalies: AnomalyAlert[];
  funnelStages: FunnelStage[];
  tavusReports: TavusReport[];
  competitors: Competitor[];
  aiQueries: AiQuery[];
  integrations: Integration[];
  user: User;
  selectedDateRange: DateRange;
  isLoading: boolean;
  error: string | null;
};
