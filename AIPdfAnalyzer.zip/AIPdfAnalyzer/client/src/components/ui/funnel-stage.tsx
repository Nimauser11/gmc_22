import React from "react";
import { cn } from "@/lib/utils";
import { ArrowDown } from "lucide-react";

interface FunnelStageProps {
  name: string;
  value: number;
  percentage: number;
  dropPercentage?: number;
  className?: string;
}

const FunnelStage: React.FC<FunnelStageProps> = ({
  name,
  value,
  percentage,
  dropPercentage,
  className,
}) => {
  return (
    <div className={cn("relative", className)}>
      <div className="flex justify-between items-center mb-1">
        <span className="text-sm font-medium">{name}</span>
        <span className="text-sm">{value.toLocaleString()}</span>
      </div>
      <div className="bg-neutral-100 h-6 w-full rounded-md overflow-hidden">
        <div
          className="bg-primary h-full"
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
      {typeof dropPercentage !== "undefined" && (
        <div className="absolute -top-1 right-0 text-xs text-neutral-600">
          <span className="inline-flex items-center">
            <ArrowDown className="h-3 w-3 mr-1 text-error-500" />
            {dropPercentage}%
          </span>
        </div>
      )}
    </div>
  );
};

export default FunnelStage;
