import React from "react";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { ArrowUp, ArrowDown } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  previousValue?: string | number;
  change?: number;
  trend?: "up" | "down";
  trendColor?: "success" | "error" | "warning" | "neutral";
  className?: string;
  children?: React.ReactNode;
  footer?: React.ReactNode;
}

const StatsCard: React.FC<StatsCardProps> = ({
  title,
  value,
  previousValue,
  change,
  trend = "up",
  trendColor = "success",
  className,
  children,
  footer,
}) => {
  const getTrendColor = () => {
    switch (trendColor) {
      case "success":
        return "bg-success-50 text-success-700";
      case "error":
        return "bg-error-50 text-error-700";
      case "warning":
        return "bg-warning-50 text-warning-700";
      default:
        return "bg-neutral-100 text-neutral-600";
    }
  };

  const getTrendIcon = () => {
    return trend === "up" ? (
      <ArrowUp className="h-3 w-3 mr-1" />
    ) : (
      <ArrowDown className="h-3 w-3 mr-1" />
    );
  };

  return (
    <Card className={cn("shadow-sm", className)}>
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-3">
          <div>
            <p className="text-neutral-600 text-sm">{title}</p>
            <h3 className="text-2xl font-semibold">{value}</h3>
          </div>
          {typeof change !== "undefined" && (
            <span
              className={cn(
                "px-2 py-1 text-xs rounded-full flex items-center",
                getTrendColor()
              )}
            >
              {getTrendIcon()}
              {Math.abs(change)}%
            </span>
          )}
        </div>
        <div className="chart-container">
          {children}
        </div>
        {footer && (
          <p className="text-sm text-neutral-600 mt-1">{footer}</p>
        )}
      </CardContent>
    </Card>
  );
};

export default StatsCard;
