import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Play, UserRound, Users, HeadphonesIcon, PlusIcon } from 'lucide-react';
import { TavusReport } from '@/types';
import { createTavusReport } from '@/lib/api';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface TavusIntegrationProps {
  tavusReports: TavusReport[];
}

const TavusIntegration: React.FC<TavusIntegrationProps> = ({ tavusReports }) => {
  const { toast } = useToast();
  const [isCreating, setIsCreating] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [reportType, setReportType] = useState<string>('investor');
  const [reportTitle, setReportTitle] = useState<string>('');

  const handleCreateReport = async () => {
    if (!reportTitle.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide a report title",
        variant: "destructive",
      });
      return;
    }

    setIsCreating(true);
    try {
      await createTavusReport({
        title: reportTitle,
        reportType: reportType as 'investor' | 'team' | 'customer' | 'custom'
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/tavus/reports'] });
      
      toast({
        title: "Report created",
        description: "Your Tavus video report is being generated",
      });
      
      setOpenDialog(false);
      setReportTitle('');
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create report",
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  const latestReport = tavusReports.length > 0 ? tavusReports[0] : null;

  const [selectedVideo, setSelectedVideo] = useState<TavusReport | null>(null);
  const [isVideoDialogOpen, setIsVideoDialogOpen] = useState(false);
  
  const openVideoPlayer = (report: TavusReport) => {
    setSelectedVideo(report);
    setIsVideoDialogOpen(true);
  };

  return (
    <>
      <Card className="shadow-sm">
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Tavus Video Reports</h2>
            <Dialog open={openDialog} onOpenChange={setOpenDialog}>
              <DialogTrigger asChild>
                <Button variant="link" className="text-primary text-sm">Create New</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Tavus Video Report</DialogTitle>
                  <DialogDescription>
                    Generate a personalized video report using Tavus AI.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="report-title" className="text-right">
                      Title
                    </Label>
                    <Input
                      id="report-title"
                      value={reportTitle}
                      onChange={(e) => setReportTitle(e.target.value)}
                      className="col-span-3"
                      placeholder="Weekly Investor Update"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="report-type" className="text-right">
                      Type
                    </Label>
                    <Select value={reportType} onValueChange={setReportType}>
                      <SelectTrigger id="report-type" className="col-span-3">
                        <SelectValue placeholder="Select report type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="investor">Investor Report</SelectItem>
                        <SelectItem value="team">Team Update</SelectItem>
                        <SelectItem value="customer">Customer Brief</SelectItem>
                        <SelectItem value="custom">Custom Report</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleCreateReport} disabled={isCreating}>
                    {isCreating ? "Creating..." : "Create Report"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          
          <div className="mb-4">
            <p className="text-neutral-600 text-sm mb-4">Generate personalized video reports using Tavus AI for your team and investors.</p>
            
            {latestReport ? (
              <div 
                className="relative overflow-hidden rounded-lg bg-neutral-900 h-48 flex items-center justify-center mb-4 cursor-pointer"
                onClick={() => openVideoPlayer(latestReport)}
              >
                {latestReport.thumbnailUrl ? (
                  <img 
                    src={latestReport.thumbnailUrl} 
                    alt="Video thumbnail" 
                    className="w-full h-full object-cover opacity-70"
                  />
                ) : (
                  <div className="w-full h-full bg-neutral-800" />
                )}
                <div className="absolute inset-0 flex items-center justify-center">
                  {latestReport.videoUrl && latestReport.videoUrl.startsWith('tavus:processing') ? (
                    <div className="text-center">
                      <div className="animate-spin h-10 w-10 border-4 border-primary border-t-transparent rounded-full mx-auto mb-2"></div>
                      <p className="text-white text-sm">Processing</p>
                    </div>
                  ) : (
                    <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all">
                      <Play className="h-8 w-8 text-white" />
                    </div>
                  )}
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black to-transparent">
                  <h3 className="text-white font-medium">{latestReport.title}</h3>
                  <p className="text-neutral-300 text-sm">Generated {new Date(latestReport.createdAt).toLocaleDateString()}</p>
                </div>
              </div>
            ) : (
              <div className="relative overflow-hidden rounded-lg bg-neutral-800 h-48 flex items-center justify-center mb-4">
                <div className="text-white text-center p-4">
                  <Play className="h-10 w-10 mx-auto mb-2 opacity-40" />
                  <p>No reports generated yet</p>
                  <p className="text-sm text-neutral-400">Create your first video report</p>
                </div>
              </div>
            )}
            
            {tavusReports.length > 1 && (
              <div className="grid grid-cols-3 gap-2 mb-4">
                {tavusReports.slice(1, 4).map((report) => (
                  <div 
                    key={report.id}
                    className="relative overflow-hidden rounded-lg aspect-video bg-neutral-800 cursor-pointer"
                    onClick={() => openVideoPlayer(report)}
                  >
                    {report.thumbnailUrl ? (
                      <img 
                        src={report.thumbnailUrl} 
                        alt={report.title} 
                        className="w-full h-full object-cover opacity-70"
                      />
                    ) : (
                      <div className="w-full h-full bg-neutral-800" />
                    )}
                    <div className="absolute inset-0 flex items-center justify-center">
                      {report.videoUrl && report.videoUrl.startsWith('tavus:processing') ? (
                        <div className="text-center">
                          <div className="animate-spin h-7 w-7 border-3 border-primary border-t-transparent rounded-full mx-auto mb-1"></div>
                          <p className="text-white text-xs">Processing</p>
                        </div>
                      ) : (
                        <div className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all">
                          <Play className="h-5 w-5 text-white" />
                        </div>
                      )}
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black to-transparent">
                      <h3 className="text-white text-xs font-medium truncate">{report.title}</h3>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            <div className="grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                className="flex flex-col items-center p-3 h-auto"
                onClick={() => {
                  setReportType('investor');
                  setOpenDialog(true);
                }}
              >
                <UserRound className="h-6 w-6 text-primary mb-1" />
                <span className="text-sm font-medium">Investor Report</span>
              </Button>
              
              <Button 
                variant="outline" 
                className="flex flex-col items-center p-3 h-auto"
                onClick={() => {
                  setReportType('team');
                  setOpenDialog(true);
                }}
              >
                <Users className="h-6 w-6 text-primary mb-1" />
                <span className="text-sm font-medium">Team Update</span>
              </Button>
              
              <Button 
                variant="outline" 
                className="flex flex-col items-center p-3 h-auto"
                onClick={() => {
                  setReportType('customer');
                  setOpenDialog(true);
                }}
              >
                <HeadphonesIcon className="h-6 w-6 text-primary mb-1" />
                <span className="text-sm font-medium">Customer Brief</span>
              </Button>
              
              <Button 
                variant="outline" 
                className="flex flex-col items-center p-3 h-auto"
                onClick={() => {
                  setReportType('custom');
                  setOpenDialog(true);
                }}
              >
                <PlusIcon className="h-6 w-6 text-primary mb-1" />
                <span className="text-sm font-medium">Custom Report</span>
              </Button>
            </div>
          </div>
          
          <div className="p-3 bg-secondary-50 rounded-md text-sm">
            <span className="font-medium">Tip:</span> Personalized videos generate 3x more engagement than generic updates. Try creating a Tavus video for your next investor update.
          </div>
        </CardContent>
      </Card>

      {/* Video Player Dialog */}
      <Dialog open={isVideoDialogOpen} onOpenChange={setIsVideoDialogOpen}>
        <DialogContent className="sm:max-w-[720px]">
          <DialogHeader>
            <DialogTitle>{selectedVideo?.title}</DialogTitle>
            <DialogDescription>
              {selectedVideo?.reportType === 'investor' ? 'Investor Report' : 
               selectedVideo?.reportType === 'team' ? 'Team Update' : 
               selectedVideo?.reportType === 'customer' ? 'Customer Brief' : 'Custom Report'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="bg-black rounded-md overflow-hidden" style={{height: "400px"}}>
            {selectedVideo?.videoUrl && selectedVideo.videoUrl.startsWith('tavus:processing') ? (
              <div className="w-full h-full flex flex-col items-center justify-center text-white">
                <div className="animate-spin h-10 w-10 border-4 border-primary border-t-transparent rounded-full mb-4"></div>
                <h3 className="text-lg font-medium mb-2">Video is being generated</h3>
                <p className="text-sm text-gray-400">The Tavus AI is creating your personalized video. This may take a few minutes.</p>
              </div>
            ) : (
              <iframe 
                src={selectedVideo?.videoUrl}
                className="w-full h-full"
                frameBorder="0"
                allow="autoplay; fullscreen; picture-in-picture"
                allowFullScreen
              ></iframe>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsVideoDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default TavusIntegration;
