import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Brain, Send } from 'lucide-react';
import { AiQuery } from '@/types';
import { askKpixQuestion } from '@/lib/api';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';

interface AskKPIxProps {
  previousQueries: AiQuery[];
}

const AskKPIx: React.FC<AskKPIxProps> = ({ previousQueries }) => {
  const { toast } = useToast();
  const [query, setQuery] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!query.trim()) return;
    
    setIsSubmitting(true);
    try {
      await askKpixQuestion(query);
      queryClient.invalidateQueries({ queryKey: ['/api/ask/history'] });
      setQuery('');
      
      toast({
        title: "Question submitted",
        description: "Your question has been received",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process your question",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const submitQuestion = (suggestedQuery: string) => {
    setQuery(suggestedQuery);
    handleSubmit(new Event('submit') as unknown as React.FormEvent);
  };

  // Get most recent query/response pair
  const recentQuery = previousQueries.length > 0 ? previousQueries[0] : null;

  return (
    <div className="mt-6">
      <Card className="shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center mb-4">
            <div className="h-10 w-10 bg-primary-100 rounded-full flex items-center justify-center">
              <Brain className="h-5 w-5 text-primary" />
            </div>
            <div className="ml-3">
              <h2 className="text-lg font-semibold">Ask KPIx</h2>
              <p className="text-sm text-neutral-600">Ask questions about your metrics and get AI-powered insights</p>
            </div>
          </div>
          
          <div className="space-y-4">
            {recentQuery && (
              <div className="p-3 bg-neutral-50 rounded-lg">
                <p className="text-sm italic text-neutral-600 mb-2">"{recentQuery.query}"</p>
                <div className="bg-white p-3 rounded border border-neutral-200">
                  <p className="text-sm text-neutral-700 whitespace-pre-line">
                    {recentQuery.response}
                  </p>
                </div>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="flex">
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ask about your metrics, growth, or competitors..."
                className="flex-1 rounded-r-none"
                disabled={isSubmitting}
              />
              <Button 
                type="submit" 
                className="rounded-l-none"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <div className="animate-spin w-4 h-4 border-2 border-background border-t-transparent rounded-full" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </form>
            
            <div className="flex flex-wrap justify-center gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="text-xs"
                onClick={() => submitQuestion("How can I increase conversions?")}
              >
                How can I increase conversions?
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="text-xs"
                onClick={() => submitQuestion("What's my best traffic source?")}
              >
                What's my best traffic source?
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="text-xs"
                onClick={() => submitQuestion("Compare to last month")}
              >
                Compare to last month
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AskKPIx;
