import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, LineChart, AlertTriangle } from 'lucide-react';
import { AnomalyAlert } from '@/types';
import { updateAnomalyStatus } from '@/lib/api';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';

interface AnomalyAlertsProps {
  anomalies: AnomalyAlert[];
}

const AnomalyAlerts: React.FC<AnomalyAlertsProps> = ({ anomalies }) => {
  const { toast } = useToast();

  const handleStatusChange = async (id: string, status: string) => {
    try {
      await updateAnomalyStatus(id, status);
      queryClient.invalidateQueries({ queryKey: ['/api/anomalies'] });
      toast({
        title: "Status updated",
        description: `Alert status changed to ${status}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update status",
        variant: "destructive",
      });
    }
  };

  const getIcon = (severity: string) => {
    switch (severity) {
      case 'warning':
        return <AlertTriangle className="h-5 w-5" />;
      case 'success':
        return <LineChart className="h-5 w-5" />;
      case 'error':
        return <AlertCircle className="h-5 w-5" />;
      default:
        return <AlertCircle className="h-5 w-5" />;
    }
  };

  const getIconBgClass = (severity: string) => {
    switch (severity) {
      case 'warning':
        return 'bg-warning-500';
      case 'success':
        return 'bg-success-500';
      case 'error':
        return 'bg-error-500';
      default:
        return 'bg-primary';
    }
  };

  const getCardBgClass = (severity: string) => {
    switch (severity) {
      case 'warning':
        return 'bg-warning-50';
      case 'success':
        return 'bg-white';
      case 'error':
        return 'bg-error-50';
      default:
        return 'bg-white';
    }
  };

  const getPrimaryButtonLabel = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Investigate';
      case 'investigating':
        return 'Resolve';
      case 'resolved':
        return 'Reopen';
      default:
        return 'Investigate';
    }
  };

  const getPrimaryButtonAction = (status: string) => {
    switch (status) {
      case 'pending':
        return 'investigating';
      case 'investigating':
        return 'resolved';
      case 'resolved':
        return 'pending';
      default:
        return 'investigating';
    }
  };

  const getPrimaryButtonColor = (severity: string) => {
    switch (severity) {
      case 'warning':
        return 'bg-warning-500 hover:bg-warning-600 text-white';
      case 'success':
        return 'bg-primary hover:bg-primary-600 text-white';
      case 'error':
        return 'bg-error-500 hover:bg-error-600 text-white';
      default:
        return 'bg-primary hover:bg-primary-600 text-white';
    }
  };

  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Anomaly Alerts</h2>
        <Button variant="link" className="text-primary text-sm flex items-center">
          <span>View All</span>
          <svg
            width="15"
            height="15"
            viewBox="0 0 15 15"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="h-4 w-4 ml-1"
          >
            <path
              d="M8.14645 3.14645C8.34171 2.95118 8.65829 2.95118 8.85355 3.14645L12.8536 7.14645C13.0488 7.34171 13.0488 7.65829 12.8536 7.85355L8.85355 11.8536C8.65829 12.0488 8.34171 12.0488 8.14645 11.8536C7.95118 11.6583 7.95118 11.3417 8.14645 11.1464L11.2929 8H2.5C2.22386 8 2 7.77614 2 7.5C2 7.22386 2.22386 7 2.5 7H11.2929L8.14645 3.85355C7.95118 3.65829 7.95118 3.34171 8.14645 3.14645Z"
              fill="currentColor"
              fillRule="evenodd"
              clipRule="evenodd"
            ></path>
          </svg>
        </Button>
      </div>
      
      <Card className="shadow-sm overflow-hidden">
        {anomalies.map((anomaly) => (
          <div 
            key={anomaly.id} 
            className={`p-4 border-b border-neutral-200 flex items-start ${getCardBgClass(anomaly.severity)}`}
          >
            <div className={`flex items-center justify-center w-8 h-8 ${getIconBgClass(anomaly.severity)} text-white rounded-full flex-shrink-0 mr-4`}>
              {getIcon(anomaly.severity)}
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <h3 className="font-medium">{anomaly.title}</h3>
                <span className="text-sm text-neutral-500">{anomaly.time}</span>
              </div>
              <p className="text-neutral-700 mt-1">{anomaly.description}</p>
              <div className="mt-3 flex gap-2">
                <Button 
                  className={`px-3 py-1 text-sm rounded-md ${getPrimaryButtonColor(anomaly.severity)}`}
                  onClick={() => handleStatusChange(anomaly.id, getPrimaryButtonAction(anomaly.status))}
                >
                  {getPrimaryButtonLabel(anomaly.status)}
                </Button>
                <Button 
                  variant="outline"
                  className="px-3 py-1 border border-neutral-300 text-neutral-700 text-sm rounded-md"
                  onClick={() => handleStatusChange(anomaly.id, 'dismissed')}
                >
                  {anomaly.status === 'dismissed' ? 'Unignore' : 'Dismiss'}
                </Button>
              </div>
            </div>
          </div>
        ))}
      </Card>
    </div>
  );
};

export default AnomalyAlerts;
