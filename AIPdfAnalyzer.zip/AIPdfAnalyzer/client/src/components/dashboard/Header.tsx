import React from 'react';
import { Bell, FileBarChart, BrainCircuit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DateRange } from '@/types';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface HeaderProps {
  selectedDateRange: DateRange;
  dateRanges: DateRange[];
  onDateRangeChange: (dateRange: DateRange) => void;
  onRefreshData: () => void;
}

const Header: React.FC<HeaderProps> = ({
  selectedDateRange,
  dateRanges,
  onDateRangeChange,
  onRefreshData,
}) => {
  return (
    <header className="bg-white border-b border-neutral-200 h-16 flex items-center px-4 md:px-6">
      <div className="flex-1 flex items-center">
        <h1 className="text-xl font-semibold">Dashboard</h1>
        <span className="ml-2 px-2 py-1 text-xs bg-success-50 text-success-700 rounded-full">Live</span>
      </div>
      
      <div className="flex items-center space-x-4">
        {/* Ask KPIx Button */}
        <Button variant="outline" className="hidden md:flex items-center space-x-2">
          <BrainCircuit className="h-4 w-4" />
          <span>Ask KPIx</span>
        </Button>
        
        {/* Create Report Button */}
        <Button className="flex items-center space-x-2">
          <FileBarChart className="h-4 w-4" />
          <span className="hidden md:inline">Create Report</span>
        </Button>
        
        {/* Notifications */}
        <div className="relative">
          <Button variant="ghost" size="icon" className="text-neutral-600 hover:text-neutral-900">
            <Bell className="h-5 w-5" />
          </Button>
          <span className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center text-xs bg-destructive text-white rounded-full">3</span>
        </div>

        {/* Date Range Selector */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="flex items-center space-x-2">
              <span>{selectedDateRange.label}</span>
              <svg
                width="15"
                height="15"
                viewBox="0 0 15 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4"
              >
                <path
                  d="M3.13523 6.15803C3.3241 5.95657 3.64052 5.94637 3.84197 6.13523L7.5 9.56464L11.158 6.13523C11.3595 5.94637 11.6759 5.95657 11.8648 6.15803C12.0536 6.35949 12.0434 6.67591 11.842 6.86477L7.84197 10.6148C7.64964 10.7951 7.35036 10.7951 7.15803 10.6148L3.15803 6.86477C2.95657 6.67591 2.94637 6.35949 3.13523 6.15803Z"
                  fill="currentColor"
                  fillRule="evenodd"
                  clipRule="evenodd"
                ></path>
              </svg>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {dateRanges.map((range) => (
              <DropdownMenuItem 
                key={range.value}
                onClick={() => onDateRangeChange(range)}
              >
                {range.label}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Refresh Button */}
        <Button 
          variant="outline" 
          size="icon"
          onClick={onRefreshData}
        >
          <svg
            width="15"
            height="15"
            viewBox="0 0 15 15"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="h-4 w-4"
          >
            <path
              d="M1.84998 7.49998C1.84998 4.66458 4.05979 2.34998 6.89519 2.34998C9.11322 2.34998 10.9483 3.59961 11.7684 5.36211C11.9133 5.67664 12.2554 5.81519 12.5699 5.67023C12.8844 5.52527 13.023 5.18324 12.878 4.86872C11.8708 2.70704 9.62663 1.14998 6.89519 1.14998C3.38723 1.14998 0.649979 4.00583 0.649979 7.49998C0.649979 10.994 3.38723 13.85 6.89519 13.85C8.07221 13.85 9.16512 13.511 10.0937 12.9171L8.62479 11.7986C8.09915 12.0293 7.51286 12.15 6.89519 12.15C4.05979 12.15 1.84998 9.83537 1.84998 7.49998ZM14.15 7.49998C14.15 6.9421 13.6769 6.49998 13.09 6.49998H8.65001C8.0631 6.49998 7.59001 6.9421 7.59001 7.49998C7.59001 8.05786 8.0631 8.49998 8.65001 8.49998H10.8L7.87948 10.9236C7.5474 11.1844 7.48881 11.6652 7.74972 11.9973C8.01062 12.3294 8.49135 12.388 8.82344 12.1271L13.09 8.58219V10.5C13.09 11.0579 13.5631 11.5 14.15 11.5C14.7369 11.5 15.21 11.0579 15.21 10.5V8.49998C15.21 8.40008 15.1928 8.30407 15.1585 8.21632C15.1585 8.21631 15.1585 8.2163 15.1585 8.21629L15.1581 8.21522C15.0724 7.97011 14.8674 7.77358 14.6162 7.68494L14.6152 7.68453C14.4741 7.62851 14.3176 7.59859 14.15 7.59859L14.15 7.49998Z"
              fill="currentColor"
              fillRule="evenodd"
              clipRule="evenodd"
            ></path>
          </svg>
        </Button>
      </div>
    </header>
  );
};

export default Header;
