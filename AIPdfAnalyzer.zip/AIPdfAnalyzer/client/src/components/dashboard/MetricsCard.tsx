import React from 'react';
import StatsCard from '@/components/ui/stats-card';
import { MetricCard as MetricCardType } from '@/types';

interface MetricsCardProps {
  metric: MetricCardType;
}

const MetricsCard: React.FC<MetricsCardProps> = ({ metric }) => {
  const getFooterText = () => {
    return `vs. ${metric.previousValue} last period`;
  };

  const getTrendColor = () => {
    if (metric.title.toLowerCase().includes('abandonment') || metric.title.toLowerCase().includes('bounce')) {
      return metric.trend === 'up' ? 'error' : 'success';
    }
    return metric.trend === 'up' ? 'success' : 'error';
  };

  return (
    <StatsCard
      title={metric.title}
      value={metric.value}
      previousValue={metric.previousValue}
      change={metric.changePercentage}
      trend={metric.trend}
      trendColor={getTrendColor()}
      footer={getFooterText()}
    >
      <div className="h-full flex items-end space-x-1">
        {metric.chartData.map((value, index) => {
          const isRecent = index >= metric.chartData.length - 2;
          const bgColorClass = isRecent 
            ? metric.source === 'revenue' || metric.source === 'conversion' 
              ? 'bg-primary' 
              : metric.source === 'traffic' 
                ? 'bg-secondary-500' 
                : 'bg-error-500'
            : metric.source === 'revenue' || metric.source === 'conversion' 
              ? 'bg-primary-200' 
              : metric.source === 'traffic' 
                ? 'bg-secondary-200' 
                : 'bg-error-200';
          
          return (
            <div 
              key={index}
              className={`${bgColorClass} w-1/12 rounded-t`}
              style={{ height: `${(value / Math.max(...metric.chartData)) * 100}%` }}
            ></div>
          );
        })}
      </div>
    </StatsCard>
  );
};

export default MetricsCard;
