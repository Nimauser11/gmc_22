import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Competitor } from '@/types';

interface CompetitorAnalysisProps {
  competitors: Competitor[];
}

const CompetitorAnalysis: React.FC<CompetitorAnalysisProps> = ({ competitors }) => {
  return (
    <div className="mt-6">
      <Card className="shadow-sm">
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Competitor Analysis</h2>
            <Button variant="link" className="text-primary text-sm">View All</Button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="border-b border-neutral-200">
                  <th className="py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Competitor</th>
                  <th className="py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Traffic</th>
                  <th className="py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Growth</th>
                  <th className="py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Top Channels</th>
                  <th className="py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Content Strategy</th>
                </tr>
              </thead>
              <tbody>
                {competitors.map((competitor) => (
                  <tr key={competitor.id} className="border-b border-neutral-200">
                    <td className="py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-8 w-8 bg-neutral-100 rounded-full flex items-center justify-center">
                          <span className="text-neutral-700 font-medium">{competitor.initial}</span>
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-neutral-900">{competitor.name}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 whitespace-nowrap">
                      <p className="text-sm text-neutral-900">{competitor.traffic}</p>
                    </td>
                    <td className="py-4 whitespace-nowrap">
                      <Badge variant={competitor.growth > 0 ? "success" : "destructive"} className="px-2 py-1 text-xs">
                        {competitor.growth > 0 ? '+' : ''}{competitor.growth}%
                      </Badge>
                    </td>
                    <td className="py-4 whitespace-nowrap">
                      <div className="flex space-x-1">
                        {competitor.channels.map((channel, index) => (
                          <Badge key={index} variant="outline" className="px-2 py-1 text-xs bg-neutral-100">
                            {channel}
                          </Badge>
                        ))}
                      </div>
                    </td>
                    <td className="py-4">
                      <p className="text-sm text-neutral-600">{competitor.strategy}</p>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="mt-4 p-3 bg-secondary-50 rounded-md text-sm">
            <span className="font-medium">AI Insight:</span> Competitor C is showing strong growth with their video content strategy. Consider allocating more resources to video production and influencer partnerships.
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CompetitorAnalysis;
