import React from 'react';
import { Link, useLocation } from 'wouter';
import { cn } from '@/lib/utils';
import { Integration, User } from '@/types';
import {
  LayoutDashboard,
  LineChart,
  UserSearch,
  VideoIcon,
  Settings,
  ShoppingBag,
  CreditCard,
  Instagram,
  Linkedin,
} from 'lucide-react';
import { RiGoogleLine } from 'react-icons/ri';

interface SidebarProps {
  integrations: Integration[];
  user: User;
}

const Sidebar: React.FC<SidebarProps> = ({ integrations, user }) => {
  const [location] = useLocation();

  const navigationItems = [
    { href: '/dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-5 w-5" /> },
    { href: '/analytics', label: 'Analytics', icon: <LineChart className="h-5 w-5" /> },
    { href: '/competitors', label: 'Competitors', icon: <UserSearch className="h-5 w-5" /> },
    { href: '/tavus-reports', label: 'Tavus Reports', icon: <VideoIcon className="h-5 w-5" /> },
    { href: '/settings', label: 'Settings', icon: <Settings className="h-5 w-5" /> },
  ];

  const getIntegrationIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'shopify':
        return <ShoppingBag className="h-4 w-4 text-neutral-300" />;
      case 'stripe':
        return <CreditCard className="h-4 w-4 text-neutral-300" />;
      case 'google_analytics':
        return <RiGoogleLine className="h-4 w-4 text-neutral-300" />;
      case 'linkedin':
        return <Linkedin className="h-4 w-4 text-neutral-300" />;
      case 'instagram':
        return <Instagram className="h-4 w-4 text-neutral-300" />;
      default:
        return <div className="h-4 w-4 text-neutral-300" />;
    }
  };

  return (
    <aside className="w-16 md:w-64 flex-shrink-0 bg-neutral-900 text-white flex flex-col transition-all duration-300 z-10">
      <div className="flex items-center justify-center h-16 border-b border-neutral-700">
        <div className="md:hidden text-2xl font-bold">K</div>
        <div className="hidden md:block text-2xl font-bold">KPIx</div>
      </div>
      
      <div className="p-3 md:p-4 flex-grow">
        <nav>
          {navigationItems.map((item) => (
            <Link 
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center mb-2 p-2 rounded-md", 
                location === item.href 
                  ? "bg-primary text-white" 
                  : "text-neutral-300 hover:bg-neutral-800"
              )}
            >
              {item.icon}
              <span className="ml-3 hidden md:inline">{item.label}</span>
            </Link>
          ))}
        </nav>
        
        <div className="mt-8 pt-6 border-t border-neutral-700">
          <h3 className="text-xs uppercase text-neutral-400 font-semibold mb-2 hidden md:block">Integrations</h3>
          
          {integrations.map((integration) => (
            <div key={integration.id} className="flex items-center mb-2 p-2">
              <div className={cn(
                "h-2 w-2 rounded-full mr-2",
                integration.isConnected ? "bg-success-500" : "bg-neutral-600"
              )}></div>
              {getIntegrationIcon(integration.type)}
              <span 
                className={cn(
                  "ml-2 text-sm hidden md:inline",
                  integration.isConnected ? "text-neutral-300" : "text-neutral-600"
                )}
              >
                {integration.name}
              </span>
            </div>
          ))}
        </div>
      </div>
      
      <div className="p-4 border-t border-neutral-700 flex items-center">
        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white">
          <span>{user?.initials}</span>
        </div>
        <div className="ml-3 hidden md:block">
          <p className="text-sm font-medium text-white">{user?.username}</p>
          <p className="text-xs text-neutral-400">{user?.role}</p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
