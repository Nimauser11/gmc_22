import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import FunnelStage from '@/components/ui/funnel-stage';
import { FunnelStage as FunnelStageType } from '@/types';

interface FunnelAnalysisProps {
  funnelStages: FunnelStageType[];
}

const FunnelAnalysis: React.FC<FunnelAnalysisProps> = ({ funnelStages }) => {
  return (
    <Card className="shadow-sm">
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Conversion Funnel</h2>
          <Button variant="link" className="text-primary text-sm">View Details</Button>
        </div>
        
        <div className="space-y-4">
          {funnelStages.map((stage, index) => (
            <FunnelStage
              key={stage.id}
              name={stage.name}
              value={stage.value}
              percentage={stage.percentage}
              dropPercentage={index > 0 ? stage.dropPercentage : undefined}
            />
          ))}
        </div>
        
        <div className="mt-6 p-3 bg-primary-50 rounded-md text-sm">
          <span className="font-medium">AI Insight:</span> Your largest drop-off is between product page views and add-to-cart. Consider adding social proof or improving product descriptions to increase conversion.
        </div>
      </CardContent>
    </Card>
  );
};

export default FunnelAnalysis;
