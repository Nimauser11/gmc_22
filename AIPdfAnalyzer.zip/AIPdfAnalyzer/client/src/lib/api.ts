import { apiRequest } from './queryClient';
import type {
  MetricCard,
  AnomalyAlert,
  FunnelStage,
  TavusReport,
  Competitor,
  AiQuery,
  Integration,
  User,
  DateRange
} from '@/types';

// Fetch dashboard data
export async function fetchDashboardData(dateRange: string) {
  const res = await apiRequest('GET', `/api/dashboard?dateRange=${dateRange}`, undefined);
  return res.json();
}

// Fetch metrics
export async function fetchMetrics(dateRange: string) {
  const res = await apiRequest('GET', `/api/metrics?dateRange=${dateRange}`, undefined);
  return res.json();
}

// Fetch anomalies
export async function fetchAnomalies() {
  const res = await apiRequest('GET', '/api/anomalies', undefined);
  return res.json();
}

// Update anomaly status
export async function updateAnomalyStatus(id: string, status: string) {
  const res = await apiRequest('PATCH', `/api/anomalies/${id}`, { status });
  return res.json();
}

// Fetch funnel data
export async function fetchFunnelData(dateRange: string) {
  const res = await apiRequest('GET', `/api/funnel?dateRange=${dateRange}`, undefined);
  return res.json();
}

// Fetch competitor data
export async function fetchCompetitors() {
  const res = await apiRequest('GET', '/api/competitors', undefined);
  return res.json();
}

// Fetch integrations status
export async function fetchIntegrations() {
  const res = await apiRequest('GET', '/api/integrations', undefined);
  return res.json();
}

// Toggle integration status
export async function toggleIntegration(id: string, isConnected: boolean) {
  const res = await apiRequest('PATCH', `/api/integrations/${id}`, { isConnected });
  return res.json();
}

// Fetch Tavus reports
export async function fetchTavusReports() {
  const res = await apiRequest('GET', '/api/tavus/reports', undefined);
  return res.json();
}

// Create a new Tavus report
export async function createTavusReport(reportData: Omit<TavusReport, 'id' | 'createdAt' | 'thumbnailUrl' | 'videoUrl'>) {
  const res = await apiRequest('POST', '/api/tavus/reports', reportData);
  return res.json();
}

// Ask KPIx a question
export async function askKpixQuestion(query: string) {
  const res = await apiRequest('POST', '/api/ask', { query });
  return res.json();
}

// Fetch AI query history
export async function fetchAiQueries() {
  const res = await apiRequest('GET', '/api/ask/history', undefined);
  return res.json();
}

// Fetch current user info
export async function fetchCurrentUser() {
  const res = await apiRequest('GET', '/api/users/me', undefined);
  return res.json();
}

// Update user settings
export async function updateUserSettings(settings: Partial<User>) {
  const res = await apiRequest('PATCH', '/api/users/me', settings);
  return res.json();
}

// Get available date ranges
export const getDateRanges = (): DateRange[] => {
  const today = new Date();
  
  return [
    {
      label: 'Today',
      value: 'today',
      startDate: today,
      endDate: today
    },
    {
      label: 'Yesterday',
      value: 'yesterday',
      startDate: new Date(today.getTime() - 24 * 60 * 60 * 1000),
      endDate: new Date(today.getTime() - 24 * 60 * 60 * 1000)
    },
    {
      label: 'Last 7 days',
      value: 'last_7_days',
      startDate: new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000),
      endDate: today
    },
    {
      label: 'Last 30 days',
      value: 'last_30_days',
      startDate: new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000),
      endDate: today
    },
    {
      label: 'This month',
      value: 'this_month',
      startDate: new Date(today.getFullYear(), today.getMonth(), 1),
      endDate: today
    },
    {
      label: 'Last month',
      value: 'last_month',
      startDate: new Date(today.getFullYear(), today.getMonth() - 1, 1),
      endDate: new Date(today.getFullYear(), today.getMonth(), 0)
    }
  ];
};
