import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { createApiConnector } from "./services/apiConnectors";
import { anomalyDetector } from "./services/anomalyDetection";
import { tavusService } from "./services/tavusService";
import { aiAnalysisService } from "./services/aiAnalysis";
import { apifyService } from "./services/apifyService";
import { z } from "zod";
import { insertAnomalySchema, insertTavusReportSchema, insertAiQuerySchema } from "@shared/schema";

// Helper to format metric data for frontend
const formatMetricForFrontend = (metric: any) => {
  const trend = metric.changePercentage >= 0 ? 'up' : 'down';
  
  return {
    id: metric.id.toString(),
    title: getMetricTitle(metric.metricType),
    value: formatMetricValue(metric.value, metric.metricType),
    previousValue: formatMetricValue(metric.previousValue, metric.metricType),
    changePercentage: Math.abs(metric.changePercentage),
    trend,
    chartData: generateMockChartData(metric.metricType),
    source: metric.source
  };
};

// Helper to get metric title
const getMetricTitle = (metricType: string): string => {
  switch (metricType) {
    case 'revenue': return 'Revenue';
    case 'traffic': return 'Website Traffic';
    case 'conversion': return 'Conversion Rate';
    case 'abandonment': return 'Cart Abandonment';
    default: return metricType.charAt(0).toUpperCase() + metricType.slice(1);
  }
};

// Helper to format metric value
const formatMetricValue = (value: number, metricType: string): string | number => {
  if (value === undefined || value === null) return '';
  
  switch (metricType) {
    case 'revenue': return `$${value.toLocaleString()}`;
    case 'conversion': return `${value}%`;
    case 'abandonment': return `${value}%`;
    default: return value.toLocaleString();
  }
};

// Helper to generate chart data
const generateMockChartData = (metricType: string): number[] => {
  // This would ideally come from historical data
  const baseData = [0.25, 0.4, 0.6, 0.5, 0.65, 0.75, 0.5, 0.6, 0.5, 0.8, 1.0, 0.8];
  
  // Add slight variations based on metric type for visual differentiation
  switch (metricType) {
    case 'revenue': return baseData.map(v => v * 1.0);
    case 'traffic': return baseData.map(v => v * 1.1);
    case 'conversion': return baseData.map(v => v * 0.9);
    case 'abandonment': return baseData.map(v => v * 1.2);
    default: return baseData;
  }
};

// Helper to format anomaly for frontend
const formatAnomalyForFrontend = (anomaly: any) => {
  const timeAgo = getTimeAgo(anomaly.createdAt);
  let severity: 'warning' | 'success' | 'error' = 'warning';
  let icon = 'alert';
  
  if (anomaly.severity === 'high') {
    severity = 'error';
    icon = 'error';
  } else if (anomaly.severity === 'low' && anomaly.title.includes('Performance')) {
    severity = 'success';
    icon = 'chart';
  }
  
  return {
    id: anomaly.id.toString(),
    title: anomaly.title,
    description: anomaly.description,
    time: timeAgo,
    severity,
    status: anomaly.status,
    icon
  };
};

// Helper to get time ago
const getTimeAgo = (date: Date): string => {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);
  
  if (diffDays > 0) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  if (diffHours > 0) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
  if (diffMins > 0) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
  return 'just now';
};

// Helper to format funnel stages for frontend
const formatFunnelStages = (metrics: any[]) => {
  // Simplified funnel data
  return [
    {
      id: '1',
      name: 'Website Visitors',
      value: 24589,
      percentage: 100,
      dropPercentage: 0
    },
    {
      id: '2',
      name: 'Product Page Views',
      value: 18432,
      percentage: 75,
      dropPercentage: 25
    },
    {
      id: '3',
      name: 'Add to Cart',
      value: 5935,
      percentage: 32,
      dropPercentage: 43
    },
    {
      id: '4',
      name: 'Checkout Initiated',
      value: 1901,
      percentage: 10,
      dropPercentage: 22
    },
    {
      id: '5',
      name: 'Purchases Completed',
      value: 935,
      percentage: 5,
      dropPercentage: 5
    }
  ];
};

// Helper to format Tavus reports for frontend
const formatTavusReportsForFrontend = (reports: any[]) => {
  return reports.map(report => ({
    id: report.id.toString(),
    title: report.title,
    createdAt: getTimeAgo(report.createdAt),
    thumbnailUrl: report.thumbnailUrl || '',
    videoUrl: report.videoUrl || '',
    reportType: report.reportType
  }));
};

// Helper to format competitors for frontend
const formatCompetitorsForFrontend = (competitors: any[]) => {
  return competitors.map(competitor => ({
    id: competitor.id.toString(),
    name: competitor.name,
    initial: competitor.name.charAt(0),
    traffic: `${Math.floor(competitor.traffic / 1000)}k/mo`,
    growth: competitor.growth,
    channels: Array.isArray(competitor.channels) ? competitor.channels : [],
    strategy: competitor.contentStrategy
  }));
};

// Helper to format integrations for frontend
const formatIntegrationsForFrontend = (integrations: any[]) => {
  return integrations.map(integration => {
    let icon = '';
    let name = '';
    
    switch(integration.type) {
      case 'shopify':
        icon = 'shopping-bag';
        name = 'Shopify';
        break;
      case 'stripe':
        icon = 'credit-card';
        name = 'Stripe';
        break;
      case 'google_analytics':
        icon = 'google';
        name = 'Google Analytics';
        break;
      case 'linkedin':
        icon = 'linkedin';
        name = 'LinkedIn';
        break;
      case 'instagram':
        icon = 'instagram';
        name = 'Instagram';
        break;
      default:
        icon = 'zap';
        name = integration.type;
    }
    
    return {
      id: integration.id.toString(),
      type: integration.type,
      isConnected: integration.isConnected,
      icon,
      name
    };
  });
};

// Helper to format AI queries for frontend
const formatAiQueriesForFrontend = (queries: any[]) => {
  return queries.map(query => ({
    id: query.id.toString(),
    query: query.query,
    response: query.response,
    timestamp: query.createdAt.toISOString()
  }));
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up demo user for convenience
  const demoUserId = 1;
  
  // Dashboard data endpoint
  app.get("/api/dashboard", async (req: Request, res: Response) => {
    try {
      const dateRange = req.query.dateRange as string || 'last_7_days';
      
      // Get metrics
      const metrics = await storage.getMetrics(demoUserId, dateRange);
      
      // Get anomalies
      const anomalies = await storage.getAnomalies(demoUserId);
      
      // Get Tavus reports
      const tavusReports = await storage.getTavusReports(demoUserId);
      
      // Get competitors
      const competitors = await storage.getCompetitors(demoUserId);
      
      // Get integrations
      const integrations = await storage.getIntegrations(demoUserId);
      
      // Get AI queries
      const aiQueries = await storage.getAiQueries(demoUserId);
      
      // Get user
      const user = await storage.getUser(demoUserId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Format data for frontend
      const formattedMetrics = metrics.map(formatMetricForFrontend);
      const formattedAnomalies = anomalies.map(formatAnomalyForFrontend);
      const funnelStages = formatFunnelStages(metrics);
      const formattedTavusReports = formatTavusReportsForFrontend(tavusReports);
      const formattedCompetitors = formatCompetitorsForFrontend(competitors);
      const formattedIntegrations = formatIntegrationsForFrontend(integrations);
      const formattedAiQueries = formatAiQueriesForFrontend(aiQueries);
      
      // Format user data
      const formattedUser = {
        id: user.id.toString(),
        username: user.username,
        initials: user.username.substring(0, 2).toUpperCase(),
        role: 'Founder',
        email: user.email || ''
      };
      
      // Create date range object
      const selectedDateRange = {
        label: dateRange,
        value: dateRange,
        startDate: new Date(),
        endDate: new Date()
      };
      
      res.json({
        metrics: formattedMetrics,
        anomalies: formattedAnomalies,
        funnelStages,
        tavusReports: formattedTavusReports,
        competitors: formattedCompetitors,
        integrations: formattedIntegrations,
        aiQueries: formattedAiQueries,
        user: formattedUser,
        selectedDateRange,
        isLoading: false,
        error: null
      });
    } catch (error: any) {
      console.error("Error fetching dashboard data:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Metrics endpoint
  app.get("/api/metrics", async (req: Request, res: Response) => {
    try {
      const dateRange = req.query.dateRange as string || 'last_7_days';
      const metrics = await storage.getMetrics(demoUserId, dateRange);
      res.json(metrics.map(formatMetricForFrontend));
    } catch (error: any) {
      console.error("Error fetching metrics:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Anomalies endpoints
  app.get("/api/anomalies", async (req: Request, res: Response) => {
    try {
      const anomalies = await storage.getAnomalies(demoUserId);
      res.json(anomalies.map(formatAnomalyForFrontend));
    } catch (error: any) {
      console.error("Error fetching anomalies:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/anomalies/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;

      const schema = z.object({
        status: z.enum(['pending', 'investigating', 'resolved', 'dismissed']),
      });

      const validatedData = schema.parse({ status });
      const updatedAnomaly = await storage.updateAnomaly(id, validatedData);
      
      res.json(formatAnomalyForFrontend(updatedAnomaly));
    } catch (error: any) {
      console.error("Error updating anomaly:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Funnel data endpoint
  app.get("/api/funnel", async (req: Request, res: Response) => {
    try {
      const dateRange = req.query.dateRange as string || 'last_7_days';
      const metrics = await storage.getMetrics(demoUserId, dateRange);
      res.json(formatFunnelStages(metrics));
    } catch (error: any) {
      console.error("Error fetching funnel data:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Competitors endpoints
  app.get("/api/competitors", async (req: Request, res: Response) => {
    try {
      const competitors = await storage.getCompetitors(demoUserId);
      res.json(formatCompetitorsForFrontend(competitors));
    } catch (error: any) {
      console.error("Error fetching competitors:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Integrations endpoints
  app.get("/api/integrations", async (req: Request, res: Response) => {
    try {
      const integrations = await storage.getIntegrations(demoUserId);
      res.json(formatIntegrationsForFrontend(integrations));
    } catch (error: any) {
      console.error("Error fetching integrations:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/integrations/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { isConnected } = req.body;

      const schema = z.object({
        isConnected: z.boolean(),
      });

      const validatedData = schema.parse({ isConnected });
      const updatedIntegration = await storage.updateIntegration(id, validatedData);
      
      res.json(updatedIntegration);
    } catch (error: any) {
      console.error("Error updating integration:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Tavus reports endpoints
  app.get("/api/tavus/reports", async (req: Request, res: Response) => {
    try {
      const reports = await storage.getTavusReports(demoUserId);
      
      // Ensure all reports have video URLs for demo purposes
      const updatedReports = reports.map(report => {
        // If the report doesn't have a video URL, add a default one based on reportType
        if (!report.videoUrl) {
          let videoUrl;
          let thumbnailUrl = report.thumbnailUrl || 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';
          
          switch(report.reportType) {
            case 'investor':
              videoUrl = 'https://player.vimeo.com/video/76979871';
              break;
            case 'team':
              videoUrl = 'https://player.vimeo.com/video/305188221';
              break;
            case 'customer':
              videoUrl = 'https://player.vimeo.com/video/459890992';
              break;
            default:
              videoUrl = 'https://player.vimeo.com/video/362689204';
          }
          
          // Update the report object with the new videoUrl and thumbnailUrl
          return { ...report, videoUrl, thumbnailUrl };
        }
        return report;
      });
      
      res.json(formatTavusReportsForFrontend(updatedReports));
    } catch (error: any) {
      console.error("Error fetching Tavus reports:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tavus/reports", async (req: Request, res: Response) => {
    try {
      const { title, reportType } = req.body;
      
      // Validate request body
      const schema = insertTavusReportSchema.pick({
        title: true,
        reportType: true,
      });
      
      const validatedData = schema.parse(req.body);
      
      // Generate content based on report type
      let content = '';
      switch (reportType) {
        case 'investor':
          content = 'This week we saw an 18% increase in revenue, primarily driven by our new product line. Website traffic is up 12% thanks to our improved SEO strategy.';
          break;
        case 'team':
          content = 'Great work team! We hit our weekly targets with an 18% revenue increase. Let\'s focus on reducing the cart abandonment rate which is up 3%.';
          break;
        case 'customer':
          content = 'We\'ve added several new features based on your feedback. Our support team response time has improved by 15% and we\'ve fixed the top 3 reported issues.';
          break;
        default:
          content = 'Custom report with key metrics and insights tailored to your specific needs.';
      }
      
      // Use Tavus service to create video report
      const report = await tavusService.createVideoReport(
        demoUserId,
        validatedData.title,
        validatedData.reportType,
        content
      );
      
      // Save report to storage
      const savedReport = await storage.createTavusReport(report);
      
      res.json(formatTavusReportsForFrontend([savedReport])[0]);
    } catch (error: any) {
      console.error("Error creating Tavus report:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // AI query endpoints
  app.post("/api/ask", async (req: Request, res: Response) => {
    try {
      const { query } = req.body;
      
      // Validate request body
      const schema = z.object({
        query: z.string().min(1),
      });
      
      const validatedData = schema.parse(req.body);
      
      // Get metrics for context
      const metrics = await storage.getMetrics(demoUserId);
      const competitors = await storage.getCompetitors(demoUserId);
      
      // Use AI service to generate response
      const aiResponse = await aiAnalysisService.answerQuery(
        validatedData.query,
        { userId: demoUserId, metrics, competitors }
      );
      
      // Save query and response to storage
      const savedQuery = await storage.createAiQuery(aiResponse);
      
      res.json(formatAiQueriesForFrontend([savedQuery])[0]);
    } catch (error: any) {
      console.error("Error processing AI query:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/ask/history", async (req: Request, res: Response) => {
    try {
      const queries = await storage.getAiQueries(demoUserId);
      res.json(formatAiQueriesForFrontend(queries));
    } catch (error: any) {
      console.error("Error fetching AI query history:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // User endpoints
  app.get("/api/users/me", async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(demoUserId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        id: user.id.toString(),
        username: user.username,
        initials: user.username.substring(0, 2).toUpperCase(),
        role: 'Founder',
        email: user.email || ''
      });
    } catch (error: any) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/users/me", async (req: Request, res: Response) => {
    try {
      const { username, email, tavusApiKey, apifyApiKey } = req.body;
      
      const schema = z.object({
        username: z.string().optional(),
        email: z.string().email().optional(),
        tavusApiKey: z.string().optional(),
        apifyApiKey: z.string().optional(),
      });
      
      const validatedData = schema.parse(req.body);
      const updatedUser = await storage.updateUser(demoUserId, validatedData);
      
      res.json({
        id: updatedUser.id.toString(),
        username: updatedUser.username,
        initials: updatedUser.username.substring(0, 2).toUpperCase(),
        role: 'Founder',
        email: updatedUser.email || ''
      });
    } catch (error: any) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
