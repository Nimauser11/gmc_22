import { Metric, Competitor, Anomaly, AiQuery, InsertAiQuery } from '@shared/schema';

// Interface for AI analysis service
export interface AiAnalysisService {
  generateInsight(metrics: Metric[]): Promise<string>;
  generateCompetitorInsight(competitors: Competitor[]): Promise<string>;
  generateAnomalyInsight(anomaly: Anomaly): Promise<string>;
  answerQuery(query: string, context: any): Promise<InsertAiQuery>;
}

export class SimpleAiAnalysisService implements AiAnalysisService {
  async generateInsight(metrics: Metric[]): Promise<string> {
    // In a real implementation, this would use an LLM like OpenAI's API
    // For now, we'll return predefined insights based on the metrics
    
    if (!metrics.length) {
      return 'No metrics available for analysis.';
    }
    
    // Find the metric with the largest change (positive or negative)
    let largestChange = metrics[0];
    for (const metric of metrics) {
      if (Math.abs(metric.changePercentage ?? 0) > Math.abs(largestChange.changePercentage ?? 0)) {
        largestChange = metric;
      }
    }
    
    // Generate insight based on the metric type
    switch (largestChange.metricType) {
      case 'revenue':
        return largestChange.changePercentage > 0
          ? 'Revenue is up significantly. Consider expanding your highest-converting channels.'
          : 'Revenue has declined. Review your pricing strategy and checkout process for issues.';
        
      case 'traffic':
        return largestChange.changePercentage > 0
          ? 'Traffic is up. Consider optimizing your conversion funnel to capitalize on increased visitors.'
          : 'Traffic has decreased. Check for SEO issues or recent algorithm changes affecting your visibility.';
        
      case 'conversion':
        return largestChange.changePercentage > 0
          ? 'Conversion rate has improved. Analyze which changes led to this improvement.'
          : 'Conversion rate has dropped. Review recent site changes and user feedback.';
        
      case 'abandonment':
        return largestChange.changePercentage > 0
          ? 'Cart abandonment is up. Check for issues in your checkout process and consider exit-intent offers.'
          : 'Cart abandonment has decreased. Your recent checkout optimizations are working well.';
        
      default:
        return 'Your metrics show some changes. Continue monitoring for trends.';
    }
  }
  
  async generateCompetitorInsight(competitors: Competitor[]): Promise<string> {
    // In a real implementation, this would use an LLM
    // For now, we'll return a predefined insight based on the competitors
    
    if (!competitors.length) {
      return 'No competitor data available for analysis.';
    }
    
    // Find the fastest growing competitor
    let fastestGrowing = competitors[0];
    for (const competitor of competitors) {
      if ((competitor.growth ?? 0) > (fastestGrowing.growth ?? 0)) {
        fastestGrowing = competitor;
      }
    }
    
    if (fastestGrowing.growth > 20) {
      return `${fastestGrowing.name} is showing strong growth with their ${fastestGrowing.contentStrategy.toLowerCase()}. Consider allocating more resources to similar strategies.`;
    } else {
      return 'Your competitors show varied growth rates. Focus on differentiating your value proposition.';
    }
  }
  
  async generateAnomalyInsight(anomaly: Anomaly): Promise<string> {
    // In a real implementation, this would use an LLM
    // For now, we'll return a predefined insight based on the anomaly
    
    if (anomaly.title.includes('Abandonment')) {
      return 'Your largest drop-off is between product page views and add-to-cart. Consider adding social proof or improving product descriptions to increase conversion.';
    } else if (anomaly.title.includes('Traffic')) {
      return 'Your traffic spike coincides with your latest social media campaign. The LinkedIn posts are driving significantly more qualified leads than other channels.';
    } else if (anomaly.title.includes('Revenue')) {
      return 'The revenue increase is primarily coming from repeat customers. Your loyalty program is showing strong results.';
    } else {
      return 'This anomaly may require further investigation. Consider analyzing related metrics for patterns.';
    }
  }
  
  async answerQuery(query: string, context: any): Promise<InsertAiQuery> {
    // In a real implementation, this would use an LLM
    // For now, we'll match against predefined queries
    
    let response = '';
    
    if (query.toLowerCase().includes('cart abandonment')) {
      response = 'The cart abandonment rate increased by 32% last week primarily due to two factors:\n\n1. The new checkout flow you implemented on Tuesday is causing confusion at the payment step. Users are spending 2x longer on that page.\n2. Mobile users on iOS 16 are experiencing a rendering issue on the checkout page, causing some form fields to be hidden.\n\nRecommended actions: 1) Simplify the payment form fields, 2) Fix the iOS rendering issue, 3) Consider adding a progress indicator to the checkout flow.';
    } else if (query.toLowerCase().includes('increase conversion')) {
      response = 'To increase conversions, consider these data-driven recommendations:\n\n1. Simplify your checkout process (currently 5 steps, competitors average 3 steps)\n2. Add social proof near add-to-cart buttons (products with reviews convert 25% better)\n3. Implement exit-intent popups with discount codes (these recovered 15% of abandoning visitors in tests)\n4. Optimize for mobile users (43% of your traffic but only 22% of conversions)\n5. A/B test product page layouts (your variant B is already showing 8% better conversion)';
    } else if (query.toLowerCase().includes('traffic source')) {
      response = 'Your best traffic source based on quality (conversion rate) is LinkedIn, with a 4.2% conversion rate vs. 2.1% average.\n\nBy volume, Google organic search brings the most traffic (45% of total), but the conversion quality has decreased by 12% in the last month due to recent algorithm changes.\n\nYour LinkedIn carousel posts are getting 3x the engagement of regular posts and driving 2x the traffic. Consider creating more content in this format.';
    } else if (query.toLowerCase().includes('compare') && query.toLowerCase().includes('month')) {
      response = 'Compared to last month:\n\n✅ Revenue: $34,218 (+18%)\n✅ Traffic: 24,589 visitors (+12%)\n✅ Conversion Rate: 3.8% (+0.5%)\n❌ Cart Abandonment: 68% (+3%)\n✅ Average Order Value: $189 (+5%)\n\nKey changes from last month:\n1. Your LinkedIn strategy is driving more qualified traffic\n2. Mobile conversion has improved with the new responsive design\n3. Cart abandonment has increased, possibly due to the new checkout flow\n\nRecommendation: Focus on optimizing the checkout experience to reduce the abandonment rate.';
    } else {
      response = 'I don\'t have enough context to answer that specific question. Try asking about your metrics, conversion funnel, traffic sources, or competitor performance.';
    }
    
    return {
      userId: context.userId,
      query,
      response,
      createdAt: new Date()
    };
  }
}

export const aiAnalysisService = new SimpleAiAnalysisService();
