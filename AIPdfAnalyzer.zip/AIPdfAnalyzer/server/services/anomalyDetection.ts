import { Metric, InsertAnomaly } from '@shared/schema';

// Interface for anomaly detection service
export interface AnomalyDetector {
  detectAnomalies(metrics: Metric[], userId: number): Promise<InsertAnomaly[]>;
}

export class SimpleAnomalyDetector implements AnomalyDetector {
  // Threshold for anomaly detection as percentage change
  private thresholds = {
    revenue: 15,
    traffic: 10,
    conversion: 0.4,
    abandonment: 2,
    engagement: 12
  };
  
  // Severity mapping based on threshold multiples
  private getSeverity(metricType: string, changePercentage: number): 'low' | 'medium' | 'high' {
    const threshold = this.thresholds[metricType as keyof typeof this.thresholds] || 10;
    
    const absChange = Math.abs(changePercentage);
    
    if (absChange >= threshold * 2) {
      return 'high';
    } else if (absChange >= threshold * 1.5) {
      return 'medium';
    } else if (absChange >= threshold) {
      return 'low';
    }
    
    return 'low';
  }
  
  private getAnomalyTitle(metric: Metric): string {
    let direction = metric.changePercentage > 0 ? 'Increase' : 'Decrease';
    
    // For metrics where a decrease is good (like abandonment), flip the language
    if (metric.metricType === 'abandonment') {
      direction = metric.changePercentage > 0 ? 'Spike' : 'Drop';
    }
    
    const metricName = this.getMetricDisplayName(metric.metricType);
    
    return `${metricName} ${direction}`;
  }
  
  private getMetricDisplayName(metricType: string): string {
    const displayNames: Record<string, string> = {
      revenue: 'Revenue',
      traffic: 'Website Traffic',
      conversion: 'Conversion Rate',
      abandonment: 'Cart Abandonment Rate',
      engagement: 'Social Engagement'
    };
    
    return displayNames[metricType] || `${metricType.charAt(0).toUpperCase() + metricType.slice(1)}`;
  }
  
  private getAnomalyDescription(metric: Metric): string {
    const metricName = this.getMetricDisplayName(metric.metricType);
    const source = this.getSourceDisplayName(metric.source);
    const change = Math.abs(metric.changePercentage).toFixed(1);
    const direction = metric.changePercentage > 0 ? 'increased' : 'decreased';
    
    let description = `Your ${source} ${metricName.toLowerCase()} ${direction} by ${change}% compared to the previous period.`;
    
    // Add likely causes based on the metric type
    if (metric.metricType === 'abandonment' && metric.changePercentage > 0) {
      description += ` This may be due to checkout page issues or pricing concerns.`;
    } else if (metric.metricType === 'traffic' && metric.changePercentage < 0) {
      description += ` This could be related to recent algorithm changes or decreased ad spend.`;
    } else if (metric.metricType === 'conversion' && metric.changePercentage > 0) {
      description += ` Your recent product page updates seem to be having a positive effect.`;
    } else if (metric.metricType === 'revenue' && metric.changePercentage > 0) {
      description += ` Your latest promotion appears to be performing well.`;
    }
    
    return description;
  }
  
  private getSourceDisplayName(source: string): string {
    const displayNames: Record<string, string> = {
      stripe: 'Stripe',
      shopify: 'Shopify',
      ga: 'Google Analytics',
      linkedin: 'LinkedIn'
    };
    
    return displayNames[source] || `${source.charAt(0).toUpperCase() + source.slice(1)}`;
  }
  
  async detectAnomalies(metrics: Metric[], userId: number): Promise<InsertAnomaly[]> {
    const anomalies: InsertAnomaly[] = [];
    const now = new Date();
    
    for (const metric of metrics) {
      // Skip metrics with no change percentage
      if (metric.changePercentage === undefined || metric.changePercentage === null) {
        continue;
      }
      
      const metricType = metric.metricType as keyof typeof this.thresholds;
      const threshold = this.thresholds[metricType] || 10;
      
      // Check if the change percentage exceeds the threshold
      if (Math.abs(metric.changePercentage) >= threshold) {
        const severity = this.getSeverity(metric.metricType, metric.changePercentage);
        const title = this.getAnomalyTitle(metric);
        const description = this.getAnomalyDescription(metric);
        
        anomalies.push({
          userId,
          metricId: metric.id,
          title,
          description,
          severity,
          status: 'pending',
          createdAt: now,
          updatedAt: now
        });
      }
    }
    
    return anomalies;
  }
}

export const anomalyDetector = new SimpleAnomalyDetector();
