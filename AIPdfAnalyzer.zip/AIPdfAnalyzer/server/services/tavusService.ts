import { InsertTavusReport } from '@shared/schema';
import axios from 'axios';

// Interface for Tavus video generation service
export interface TavusService {
  createVideoReport(userId: number, title: string, reportType: string, content: string): Promise<InsertTavusReport>;
}

export class TavusApiService implements TavusService {
  private apiKey: string;
  private baseUrl: string = 'https://api.tavus.io/v2';
  
  constructor(apiKey?: string) {
    this.apiKey = apiKey || process.env.TAVUS_API_KEY || '';
    console.log('Tavus API key loaded:', this.apiKey ? `${this.apiKey.substring(0, 5)}...` : 'No API key found');
  }
  
  async createVideoReport(userId: number, title: string, reportType: string, content: string): Promise<InsertTavusReport> {
    console.log(`Creating Tavus video report for: ${title} (${reportType})`);
    
    // Generate a description based on the report type
    let description = '';
    switch (reportType) {
      case 'investor':
        description = 'Performance update for investors covering key metrics and growth';
        break;
      case 'team':
        description = 'Weekly update for the team with key progress and metrics';
        break;
      case 'customer':
        description = 'Update for customers about new features and improvements';
        break;
      default:
        description = 'Custom report with personalized content';
    }
    
    let videoUrl = '';
    let thumbnailUrl = '';
    
    if (this.apiKey) {
      try {
        console.log('Attempting to make a real Tavus API call with key:', this.apiKey);
        
        // Make an actual API call to Tavus
        const response = await axios.post(
          `${this.baseUrl}/generations`, 
          {
            script: content,
            title: title,
            metadata: {
              type: reportType,
              userId: userId.toString()
            }
          },
          {
            headers: {
              'Authorization': `Bearer ${this.apiKey}`,
              'Content-Type': 'application/json'
            }
          }
        );
        
        console.log('Tavus API response:', response.data);
        
        // In a real implementation, we would get a generation ID and then need to
        // poll for completion since video generation is asynchronous
        if (response.data && response.data.id) {
          const generationId = response.data.id;
          console.log('Tavus generation started with ID:', generationId);
          
          // For demo purposes, we'll use videoUrl that indicates the video is being processed
          // In a production app, we would need to poll the status endpoint until the video is ready
          videoUrl = `tavus:processing:${generationId}`;
          thumbnailUrl = 'https://images.unsplash.com/photo-1626795579632-a4be68e9e5bc?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';
        } else {
          throw new Error('Failed to get generation ID from Tavus API');
        }
        
      } catch (error) {
        // Add proper type checking for the error object
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        const errorResponse = (error as any)?.response?.data || errorMessage;
        
        console.error('Error creating Tavus video:', errorResponse);
        
        // If API call fails, fall back to publicly available example videos
        console.log('Falling back to example videos due to API error');
        
        switch (reportType) {
          case 'investor':
            videoUrl = 'https://player.vimeo.com/video/76979871';
            thumbnailUrl = 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';
            break;
          case 'team':
            videoUrl = 'https://player.vimeo.com/video/305188221';
            thumbnailUrl = 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';
            break;
          case 'customer':
            videoUrl = 'https://player.vimeo.com/video/459890992';
            thumbnailUrl = 'https://images.unsplash.com/photo-1581097546310-75a15c4e0df0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';
            break;
          default:
            videoUrl = 'https://player.vimeo.com/video/362689204';
            thumbnailUrl = 'https://images.unsplash.com/photo-1559136555-9303baea8ebd?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';
        }
      }
    } else {
      console.warn('No Tavus API key provided. Using placeholder video and thumbnail.');
      videoUrl = 'https://player.vimeo.com/video/362689204';
      thumbnailUrl = 'https://images.unsplash.com/photo-1626795579632-a4be68e9e5bc?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80';
    }
    
    // Return a Tavus report
    return {
      userId,
      title,
      description,
      videoUrl,
      thumbnailUrl,
      reportType: reportType,
      createdAt: new Date()
    };
  }
  
  // Add a method to check the status of a video generation
  async checkGenerationStatus(generationId: string): Promise<any> {
    if (!this.apiKey) {
      throw new Error('No Tavus API key provided');
    }
    
    try {
      const response = await axios.get(
        `${this.baseUrl}/generations/${generationId}`,
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      return response.data;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('Error checking Tavus generation status:', errorMessage);
      throw new Error(`Failed to check Tavus generation status: ${errorMessage}`);
    }
  }
  
  // Add a method to get a video URL once generation is complete
  async getVideoUrl(generationId: string): Promise<string> {
    if (!this.apiKey) {
      throw new Error('No Tavus API key provided');
    }
    
    try {
      const status = await this.checkGenerationStatus(generationId);
      
      if (status.status === 'completed') {
        // Return the URL for the completed video
        return `${this.baseUrl}/generations/${generationId}/video`;
      } else {
        // Return a placeholder indicating the video is still processing
        return 'tavus:processing';
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('Error getting Tavus video URL:', errorMessage);
      throw new Error(`Failed to get Tavus video URL: ${errorMessage}`);
    }
  }
}

export const tavusService = new TavusApiService(process.env.TAVUS_API_KEY);
