import { Metric, InsertMetric } from '@shared/schema';

// Interface for external API connectors
export interface ApiConnector {
  fetchLatestMetrics(userId: number, dateRange: string): Promise<InsertMetric[]>;
  isConnected(): boolean;
}

// Stripe API connector
export class StripeConnector implements ApiConnector {
  private apiKey: string;
  
  constructor(apiKey: string) {
    this.apiKey = apiKey || '';
  }
  
  isConnected(): boolean {
    return !!this.apiKey;
  }
  
  async fetchLatestMetrics(userId: number, dateRange: string): Promise<InsertMetric[]> {
    // In a real implementation, this would call the Stripe API
    // For now, we'll return mock data
    
    const now = new Date();
    
    // Mock revenue data
    return [
      {
        userId,
        source: 'stripe',
        metricType: 'revenue',
        value: 34218,
        previousValue: 28912,
        changePercentage: 18,
        timestamp: now,
        metadata: {
          currency: 'USD',
          dateRange
        }
      }
    ];
  }
}

// Shopify API connector
export class ShopifyConnector implements ApiConnector {
  private apiKey: string;
  
  constructor(apiKey: string) {
    this.apiKey = apiKey || '';
  }
  
  isConnected(): boolean {
    return !!this.apiKey;
  }
  
  async fetchLatestMetrics(userId: number, dateRange: string): Promise<InsertMetric[]> {
    // In a real implementation, this would call the Shopify API
    // For now, we'll return mock data
    
    const now = new Date();
    
    // Mock conversion and abandonment data
    return [
      {
        userId,
        source: 'shopify',
        metricType: 'conversion',
        value: 3.8,
        previousValue: 3.3,
        changePercentage: 0.5,
        timestamp: now,
        metadata: {
          platform: 'all',
          dateRange
        }
      },
      {
        userId,
        source: 'shopify',
        metricType: 'abandonment',
        value: 68,
        previousValue: 65,
        changePercentage: 3,
        timestamp: now,
        metadata: {
          platform: 'all',
          dateRange
        }
      }
    ];
  }
}

// Google Analytics API connector
export class GoogleAnalyticsConnector implements ApiConnector {
  private apiKey: string;
  
  constructor(apiKey: string) {
    this.apiKey = apiKey || '';
  }
  
  isConnected(): boolean {
    return !!this.apiKey;
  }
  
  async fetchLatestMetrics(userId: number, dateRange: string): Promise<InsertMetric[]> {
    // In a real implementation, this would call the Google Analytics API
    // For now, we'll return mock data
    
    const now = new Date();
    
    // Mock traffic data
    return [
      {
        userId,
        source: 'ga',
        metricType: 'traffic',
        value: 24589,
        previousValue: 21936,
        changePercentage: 12,
        timestamp: now,
        metadata: {
          source: 'organic',
          dateRange
        }
      }
    ];
  }
}

// LinkedIn API connector
export class LinkedInConnector implements ApiConnector {
  private apiKey: string;
  
  constructor(apiKey: string) {
    this.apiKey = apiKey || '';
  }
  
  isConnected(): boolean {
    return !!this.apiKey;
  }
  
  async fetchLatestMetrics(userId: number, dateRange: string): Promise<InsertMetric[]> {
    // In a real implementation, this would call the LinkedIn API
    // For now, we'll return mock data
    
    const now = new Date();
    
    // Mock engagement data
    return [
      {
        userId,
        source: 'linkedin',
        metricType: 'engagement',
        value: 3200,
        previousValue: 2800,
        changePercentage: 14.3,
        timestamp: now,
        metadata: {
          postType: 'carousel',
          dateRange
        }
      }
    ];
  }
}

// Factory for creating API connectors
export function createApiConnector(type: string, apiKey: string): ApiConnector {
  switch(type) {
    case 'stripe':
      return new StripeConnector(apiKey);
    case 'shopify':
      return new ShopifyConnector(apiKey);
    case 'google_analytics':
      return new GoogleAnalyticsConnector(apiKey);
    case 'linkedin':
      return new LinkedInConnector(apiKey);
    default:
      throw new Error(`Unsupported API connector type: ${type}`);
  }
}
