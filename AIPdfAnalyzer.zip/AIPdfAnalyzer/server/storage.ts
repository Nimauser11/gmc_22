import { 
  users, integrations, metrics, anomalies, competitors, tavusReports, aiQueries,
  type User, type InsertUser, 
  type Integration, type InsertIntegration,
  type Metric, type InsertMetric,
  type Anomaly, type InsertAnomaly,
  type Competitor, type InsertCompetitor,
  type TavusReport, type InsertTavusReport,
  type AiQuery, type InsertAiQuery
} from '@shared/schema';

// Storage interface for our application
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User>;
  
  // Integration methods
  getIntegrations(userId: number): Promise<Integration[]>;
  getIntegration(id: number): Promise<Integration | undefined>;
  createIntegration(integration: InsertIntegration): Promise<Integration>;
  updateIntegration(id: number, data: Partial<Integration>): Promise<Integration>;
  
  // Metrics methods
  getMetrics(userId: number, dateRange?: string): Promise<Metric[]>;
  createMetric(metric: InsertMetric): Promise<Metric>;
  
  // Anomaly methods
  getAnomalies(userId: number): Promise<Anomaly[]>;
  getAnomaly(id: number): Promise<Anomaly | undefined>;
  createAnomaly(anomaly: InsertAnomaly): Promise<Anomaly>;
  updateAnomaly(id: number, data: Partial<Anomaly>): Promise<Anomaly>;
  
  // Competitor methods
  getCompetitors(userId: number): Promise<Competitor[]>;
  getCompetitor(id: number): Promise<Competitor | undefined>;
  createCompetitor(competitor: InsertCompetitor): Promise<Competitor>;
  updateCompetitor(id: number, data: Partial<Competitor>): Promise<Competitor>;
  
  // Tavus report methods
  getTavusReports(userId: number): Promise<TavusReport[]>;
  getTavusReport(id: number): Promise<TavusReport | undefined>;
  createTavusReport(report: InsertTavusReport): Promise<TavusReport>;
  
  // AI query methods
  getAiQueries(userId: number): Promise<AiQuery[]>;
  createAiQuery(query: InsertAiQuery): Promise<AiQuery>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private integrations: Map<number, Integration>;
  private metrics: Map<number, Metric>;
  private anomalies: Map<number, Anomaly>;
  private competitors: Map<number, Competitor>;
  private tavusReports: Map<number, TavusReport>;
  private aiQueries: Map<number, AiQuery>;
  
  private userIdCounter: number;
  private integrationIdCounter: number;
  private metricIdCounter: number;
  private anomalyIdCounter: number;
  private competitorIdCounter: number;
  private reportIdCounter: number;
  private queryIdCounter: number;

  constructor() {
    this.users = new Map();
    this.integrations = new Map();
    this.metrics = new Map();
    this.anomalies = new Map();
    this.competitors = new Map();
    this.tavusReports = new Map();
    this.aiQueries = new Map();
    
    this.userIdCounter = 1;
    this.integrationIdCounter = 1;
    this.metricIdCounter = 1;
    this.anomalyIdCounter = 1;
    this.competitorIdCounter = 1;
    this.reportIdCounter = 1;
    this.queryIdCounter = 1;
    
    // Create demo user
    this.createUser({
      username: 'demo',
      password: 'password',
      email: 'demo@kpix.com',
      tavusApiKey: process.env.TAVUS_API_KEY || '',
      apifyApiKey: ''
    });
    
    // Create demo integrations
    const demoIntegrations = [
      { userId: 1, type: 'shopify', isConnected: true, credentials: {} },
      { userId: 1, type: 'stripe', isConnected: true, credentials: {} },
      { userId: 1, type: 'google_analytics', isConnected: true, credentials: {} },
      { userId: 1, type: 'linkedin', isConnected: true, credentials: {} },
      { userId: 1, type: 'instagram', isConnected: false, credentials: {} }
    ];
    
    demoIntegrations.forEach(integration => this.createIntegration(integration));
    
    // Create demo metrics
    const now = new Date();
    const demoMetrics = [
      { 
        userId: 1, 
        source: 'stripe', 
        metricType: 'revenue', 
        value: 34218, 
        previousValue: 28912, 
        changePercentage: 18, 
        timestamp: now,
        metadata: { currency: 'USD' }
      },
      { 
        userId: 1, 
        source: 'ga', 
        metricType: 'traffic', 
        value: 24589, 
        previousValue: 21936, 
        changePercentage: 12, 
        timestamp: now,
        metadata: { source: 'organic' }
      },
      { 
        userId: 1, 
        source: 'shopify', 
        metricType: 'conversion', 
        value: 3.8, 
        previousValue: 3.3, 
        changePercentage: 0.5, 
        timestamp: now,
        metadata: { platform: 'all' }
      },
      { 
        userId: 1, 
        source: 'shopify', 
        metricType: 'abandonment', 
        value: 68, 
        previousValue: 65, 
        changePercentage: 3, 
        timestamp: now,
        metadata: { platform: 'all' }
      }
    ];
    
    demoMetrics.forEach(metric => this.createMetric(metric));
    
    // Create demo anomalies
    const demoAnomalies = [
      {
        userId: 1,
        metricId: 4,
        title: 'Cart Abandonment Rate Spike',
        description: 'Your Shopify cart abandonment rate spiked 32% yesterday. The likely cause is the new checkout flow being tested.',
        severity: 'medium',
        status: 'pending',
        createdAt: new Date(now.getTime() - 2 * 60 * 60 * 1000),
        updatedAt: now
      },
      {
        userId: 1,
        metricId: 2,
        title: 'LinkedIn Post Performance',
        description: 'Your latest LinkedIn carousel is driving 2x more traffic than your usual posts. Consider creating more content in this format.',
        severity: 'low',
        status: 'pending',
        createdAt: new Date(now.getTime() - 5 * 60 * 60 * 1000),
        updatedAt: now
      },
      {
        userId: 1,
        metricId: 1,
        title: 'Payment Processing Error Rate',
        description: 'Stripe is showing a 5% increase in payment processing errors. Customers using Mastercard are experiencing most issues.',
        severity: 'high',
        status: 'pending',
        createdAt: new Date(now.getTime() - 24 * 60 * 60 * 1000),
        updatedAt: now
      }
    ];
    
    demoAnomalies.forEach(anomaly => this.createAnomaly(anomaly));
    
    // Create demo competitors
    const demoCompetitors = [
      {
        userId: 1,
        name: 'Competitor A',
        website: 'compA.com',
        traffic: 152000,
        growth: 23,
        channels: ['TikTok', 'SEO'],
        contentStrategy: 'Short-form video content focusing on product demos and customer testimonials',
        lastUpdated: now
      },
      {
        userId: 1,
        name: 'Competitor B',
        website: 'compB.com',
        traffic: 98000,
        growth: -5,
        channels: ['LinkedIn', 'Email'],
        contentStrategy: 'Long-form educational content with emphasis on thought leadership',
        lastUpdated: now
      },
      {
        userId: 1,
        name: 'Competitor C',
        website: 'compC.com',
        traffic: 203000,
        growth: 41,
        channels: ['YouTube', 'Instagram'],
        contentStrategy: 'Mixed content with heavy focus on influencer partnerships and UGC',
        lastUpdated: now
      }
    ];
    
    demoCompetitors.forEach(competitor => this.createCompetitor(competitor));
    
    // Create demo Tavus report
    this.createTavusReport({
      userId: 1,
      title: 'Weekly Investor Update',
      description: 'Performance update for investors covering key metrics and growth',
      videoUrl: '',
      thumbnailUrl: 'https://images.unsplash.com/photo-1626795579632-a4be68e9e5bc?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      reportType: 'investor',
      createdAt: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000)
    });
    
    // Create demo AI queries
    this.createAiQuery({
      userId: 1,
      query: 'Why did cart abandonment increase last week?',
      response: 'The cart abandonment rate increased by 32% last week primarily due to two factors:\n\n1. The new checkout flow you implemented on Tuesday is causing confusion at the payment step. Users are spending 2x longer on that page.\n2. Mobile users on iOS 16 are experiencing a rendering issue on the checkout page, causing some form fields to be hidden.\n\nRecommended actions: 1) Simplify the payment form fields, 2) Fix the iOS rendering issue, 3) Consider adding a progress indicator to the checkout flow.',
      createdAt: now
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const newUser: User = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Integration methods
  async getIntegrations(userId: number): Promise<Integration[]> {
    return Array.from(this.integrations.values()).filter(
      (integration) => integration.userId === userId
    );
  }
  
  async getIntegration(id: number): Promise<Integration | undefined> {
    return this.integrations.get(id);
  }
  
  async createIntegration(integration: InsertIntegration): Promise<Integration> {
    const id = this.integrationIdCounter++;
    const newIntegration: Integration = { ...integration, id };
    this.integrations.set(id, newIntegration);
    return newIntegration;
  }
  
  async updateIntegration(id: number, data: Partial<Integration>): Promise<Integration> {
    const integration = await this.getIntegration(id);
    if (!integration) {
      throw new Error(`Integration with id ${id} not found`);
    }
    
    const updatedIntegration = { ...integration, ...data };
    this.integrations.set(id, updatedIntegration);
    return updatedIntegration;
  }

  // Metrics methods
  async getMetrics(userId: number, dateRange?: string): Promise<Metric[]> {
    // In a real app, we'd filter by date range 
    return Array.from(this.metrics.values()).filter(
      (metric) => metric.userId === userId
    );
  }
  
  async createMetric(metric: InsertMetric): Promise<Metric> {
    const id = this.metricIdCounter++;
    const newMetric: Metric = { ...metric, id };
    this.metrics.set(id, newMetric);
    return newMetric;
  }

  // Anomaly methods
  async getAnomalies(userId: number): Promise<Anomaly[]> {
    return Array.from(this.anomalies.values())
      .filter((anomaly) => anomaly.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async getAnomaly(id: number): Promise<Anomaly | undefined> {
    return this.anomalies.get(id);
  }
  
  async createAnomaly(anomaly: InsertAnomaly): Promise<Anomaly> {
    const id = this.anomalyIdCounter++;
    const newAnomaly: Anomaly = { ...anomaly, id };
    this.anomalies.set(id, newAnomaly);
    return newAnomaly;
  }
  
  async updateAnomaly(id: number, data: Partial<Anomaly>): Promise<Anomaly> {
    const anomaly = await this.getAnomaly(id);
    if (!anomaly) {
      throw new Error(`Anomaly with id ${id} not found`);
    }
    
    const updatedAnomaly = { ...anomaly, ...data, updatedAt: new Date() };
    this.anomalies.set(id, updatedAnomaly);
    return updatedAnomaly;
  }

  // Competitor methods
  async getCompetitors(userId: number): Promise<Competitor[]> {
    return Array.from(this.competitors.values()).filter(
      (competitor) => competitor.userId === userId
    );
  }
  
  async getCompetitor(id: number): Promise<Competitor | undefined> {
    return this.competitors.get(id);
  }
  
  async createCompetitor(competitor: InsertCompetitor): Promise<Competitor> {
    const id = this.competitorIdCounter++;
    const newCompetitor: Competitor = { ...competitor, id };
    this.competitors.set(id, newCompetitor);
    return newCompetitor;
  }
  
  async updateCompetitor(id: number, data: Partial<Competitor>): Promise<Competitor> {
    const competitor = await this.getCompetitor(id);
    if (!competitor) {
      throw new Error(`Competitor with id ${id} not found`);
    }
    
    const updatedCompetitor = { ...competitor, ...data, lastUpdated: new Date() };
    this.competitors.set(id, updatedCompetitor);
    return updatedCompetitor;
  }

  // Tavus report methods
  async getTavusReports(userId: number): Promise<TavusReport[]> {
    return Array.from(this.tavusReports.values())
      .filter((report) => report.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async getTavusReport(id: number): Promise<TavusReport | undefined> {
    return this.tavusReports.get(id);
  }
  
  async createTavusReport(report: InsertTavusReport): Promise<TavusReport> {
    const id = this.reportIdCounter++;
    const newReport: TavusReport = { ...report, id };
    this.tavusReports.set(id, newReport);
    return newReport;
  }

  // AI query methods
  async getAiQueries(userId: number): Promise<AiQuery[]> {
    return Array.from(this.aiQueries.values())
      .filter((query) => query.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async createAiQuery(query: InsertAiQuery): Promise<AiQuery> {
    const id = this.queryIdCounter++;
    const newQuery: AiQuery = { ...query, id };
    this.aiQueries.set(id, newQuery);
    return newQuery;
  }
}

export const storage = new MemStorage();
