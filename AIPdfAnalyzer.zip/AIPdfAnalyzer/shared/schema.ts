import { pgTable, text, serial, integer, boolean, numeric, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  tavusApiKey: text("tavus_api_key"),
  apifyApiKey: text("apify_api_key"),
});

export const metrics = pgTable("metrics", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  source: text("source").notNull(), // 'stripe', 'shopify', 'ga', 'linkedin'
  metricType: text("metric_type").notNull(), // 'revenue', 'traffic', 'conversion', etc.
  value: numeric("value").notNull(),
  previousValue: numeric("previous_value"),
  changePercentage: numeric("change_percentage"),
  timestamp: timestamp("timestamp").notNull(),
  metadata: jsonb("metadata"),
});

export const integrations = pgTable("integrations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // 'stripe', 'shopify', 'ga', 'linkedin', etc.
  isConnected: boolean("is_connected").notNull().default(false),
  credentials: jsonb("credentials"),
  lastSync: timestamp("last_sync"),
});

export const anomalies = pgTable("anomalies", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  metricId: integer("metric_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  severity: text("severity").notNull(), // 'low', 'medium', 'high'
  status: text("status").notNull().default('pending'), // 'pending', 'investigating', 'resolved', 'dismissed'
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at"),
});

export const competitors = pgTable("competitors", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  website: text("website"),
  traffic: integer("traffic"),
  growth: numeric("growth"),
  channels: jsonb("channels"),
  contentStrategy: text("content_strategy"),
  lastUpdated: timestamp("last_updated"),
});

export const tavusReports = pgTable("tavus_reports", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  videoUrl: text("video_url"),
  thumbnailUrl: text("thumbnail_url"),
  reportType: text("report_type").notNull(), // 'investor', 'team', 'customer', 'custom'
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const aiQueries = pgTable("ai_queries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  query: text("query").notNull(),
  response: text("response"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  tavusApiKey: true,
  apifyApiKey: true,
});

export const insertMetricSchema = createInsertSchema(metrics).pick({
  userId: true,
  source: true,
  metricType: true,
  value: true,
  previousValue: true,
  changePercentage: true,
  timestamp: true,
  metadata: true,
});

export const insertIntegrationSchema = createInsertSchema(integrations).pick({
  userId: true,
  type: true,
  isConnected: true,
  credentials: true,
  lastSync: true,
});

export const insertAnomalySchema = createInsertSchema(anomalies).pick({
  userId: true,
  metricId: true,
  title: true,
  description: true,
  severity: true,
  status: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCompetitorSchema = createInsertSchema(competitors).pick({
  userId: true,
  name: true,
  website: true,
  traffic: true,
  growth: true,
  channels: true,
  contentStrategy: true,
  lastUpdated: true,
});

export const insertTavusReportSchema = createInsertSchema(tavusReports).pick({
  userId: true,
  title: true,
  description: true,
  videoUrl: true,
  thumbnailUrl: true,
  reportType: true,
  createdAt: true,
});

export const insertAiQuerySchema = createInsertSchema(aiQueries).pick({
  userId: true,
  query: true,
  response: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertMetric = z.infer<typeof insertMetricSchema>;
export type Metric = typeof metrics.$inferSelect;

export type InsertIntegration = z.infer<typeof insertIntegrationSchema>;
export type Integration = typeof integrations.$inferSelect;

export type InsertAnomaly = z.infer<typeof insertAnomalySchema>;
export type Anomaly = typeof anomalies.$inferSelect;

export type InsertCompetitor = z.infer<typeof insertCompetitorSchema>;
export type Competitor = typeof competitors.$inferSelect;

export type InsertTavusReport = z.infer<typeof insertTavusReportSchema>;
export type TavusReport = typeof tavusReports.$inferSelect;

export type InsertAiQuery = z.infer<typeof insertAiQuerySchema>;
export type AiQuery = typeof aiQueries.$inferSelect;
